/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0068;

import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class Validation {
    static Scanner scanner = new Scanner(System.in);
    
    static int checkInputLimit(int min, int max){
        int input = 0;
        while (true) {            
            try {
                input = Integer.parseInt(scanner.nextLine());
                if (input < min || input > max){
                    throw new NumberFormatException();
                }
            } catch (NumberFormatException e) {
                System.out.println("Enter again!!");
            }
        }
    }
    
    static String checkInputString(){
        while (true) {            
            String input = scanner.nextLine();
            if (input.length() == 0){
                System.out.println("Not empty.");
            } else {
                return input;
            }
        }
    }
    
    static boolean checkYN(){
        while (true) {            
            String input = scanner.nextLine();
            if (input.length() == 1 && input.equalsIgnoreCase("Y")){
                return true;
            } 
            if (input.length() == 1 && input.equalsIgnoreCase("N")){
                return false;
            }
            System.out.println("Enter again!!");
        }
    }
    
    
}
