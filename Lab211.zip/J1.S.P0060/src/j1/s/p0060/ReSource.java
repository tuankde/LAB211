/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0060;

/**
 *
 * @author Acer
 */
public class ReSource {
    final static String title = "==== Shopping program ====";
    final static String error = "Enter again!!";
    final static String numberBill = "input number of bill: ";
    final static String valueBill = "input value of bill ";
    final static String colon = ": ";
    final static String valueWallet = "input value of wallet: ";
    final static String totalBill = "This is total of bill: ";
    final static String canBuy = "You can buy it";
    final static String cantBuy = "You can't buy it.";
    final static String thisis = "This is total of bill: "; 
}
