
package j1.s.p0060;

import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class Manage {
    public static void main(String[] args) {
        System.out.println(ReSource.title);
        
        //Nhập giá tri các hoá đơn
        int[] bills = inputBills();
        
        //Nhập số tiền trong ví
        int wallet = inputWallet();
        
        //In ra màn hình tổng số tiền và kết quả
        printTotalAndResult(bills, wallet);
    }
    
    
    //đọc giá trị từ bàn phím
    static Scanner scanner = new Scanner(System.in);
    
    //kiểm tra số nguyên nhập vào
    private static int checkInputInt(){
        int input;
        while (true) {            
            try {
                input = Integer.parseInt(scanner.nextLine());
                return input;
            } catch (NumberFormatException e) {
                System.out.println(ReSource.error);
            }
        }
    }
    
    /**
     * 
     * Nhập giá trị các hoá đơn và trả về 1 mảng các số nguyên
     */
    private static int[] inputBills(){
        System.out.print(ReSource.numberBill);
        int size = checkInputInt();
        int[] bills = new int[size];
        
        //nhập giá trị từng hoá đơn
        for (int i = 0; i < bills.length; i++) {
            System.out.print(ReSource.valueBill + (i + 1) + ReSource.colon);
            bills[i] = checkInputInt();
        }
        return bills;
    }
    
    //Nhập số tiền trong ví
    private static int inputWallet(){
        System.out.print("Input value of wallet: ");
        int wallet = checkInputInt();
        return wallet;
    }
    
    //tính tổng số tiền các hoá đơn
    private static int calculate(int[] bills){
        int total = 0;
        for (int i = 0; i < bills.length; i++) {
            total += bills[i];
        }
        return total;
    }
    
    //kiểm tra số tiền tỏng ví có đủ không
    private static boolean payMoney(int total, int wallet) {
        if (total > wallet) {
            return false;
        } else {
            return true;
        }
    }
    
    /**
     * in tổng số tiền và kết quả
     * @param bills
     * @param wallet 
     */
    private static void printTotalAndResult(int[] bills, int wallet) {
        int total = calculate(bills);
        System.out.println(ReSource.thisis + total);
        if (payMoney(total, wallet)) {
            System.err.println(ReSource.canBuy);
        } else {
            System.err.println(ReSource.cantBuy);
        }
    }
    
    
}
