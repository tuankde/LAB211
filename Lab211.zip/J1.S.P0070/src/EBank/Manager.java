    package EBank;

import java.util.*;
import java.util.regex.Pattern;
import java.util.Locale;

public class Manager {

    /**
     * quản lý tin nhắn và tài nguyên ngôn ngữ.
     */
    private ResourceBundle message;
    
    private Scanner scanner = new Scanner(System.in);
    private String character = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm0123456789";

    /**
     * thong bao
     * @param locale 
     */
    public void setLocale(Locale locale) {
        message = ResourceBundle.getBundle("Language/" + locale, locale);
    }

    /**
     * kiem tra so nhap vao co du 10 hay khong
     * @param accountNumber
     * @return 
     */
    public String checkAccountNumber(String accountNumber) {
        if (!accountNumber.matches("\\d{10}")) {
            return message.getString("errorCheckInputAccount");
        }
        return null;
    }

    /**
     * kiểm tra xem độ dài mật khẩu có nằm trong khoảng từ 8 đến 31 ký tự hay không
     * @param password
     * @return 
     */
    public String checkPassword(String password) {
        if (password.length() < 8 || password.length() > 31
                || !password.matches(".*\\d.*[A-Za-z].*") && !password.matches(".*[A-Za-z].*\\d.*")) {
            return message.getString("errorCheckInputPassword");
        }
        return null;
    }

    /**
     * toa ma Captcha ngau nhien
     * @return 
     */
    public String generateCaptcha() {
        Random random = new Random();
        String captcha = "";
        int index;
        
        //tao ma captcha co 6 ki tu
        for (int i = 0; i < 6; i++) {
            index = (random.nextInt(character.length() - 1));
            captcha += character.charAt(index);
        }
        return captcha;
    }

    /**
     * kiem tra xem input co khop voi ma được toạ hay khong
     * @param captchaInput
     * @param captchaGenerated
     * @return 
     */
    public String checkCaptcha(String captchaInput, String captchaGenerated) {
        if (!captchaGenerated.equals(captchaInput)) {
            return message.getString("errorCaptchaIncorrect");
        }
        
        //valid captcha
        return null; 
    }

    /**
     * xác thực thông tin đầu vào của người dùng
     * @return 
     */
    public String inputAccount() {
        //input account.
        String account;
        String accountMessage;
        while (true) {
            System.out.println(message.getString("enterAccountNumber"));
            account = scanner.nextLine();
            accountMessage = checkAccountNumber(account);
            
            //kiem tra xem co loi khi nhap hay khong
            if (accountMessage != null) {
                System.out.println(accountMessage);
            } else {
                return account;
            }
        }
    }

    /**
     * xac thuc mat khau
     * @return 
     */
    public String inputPassword() {
        //input account.
        String password;
        String passwordMessage;
        while (true) {
            System.out.println(message.getString("enterPassword"));
            password = scanner.nextLine();
            passwordMessage = checkPassword(password);
            
            //kiem tra loi khi nhap mat khau
            if (passwordMessage != null) {
                System.out.println(passwordMessage);
            } else {
                return password;
            }
        }
    }

    /**
     * xac thuc ma Captcha
     * @return 
     */
    public String inputCaptcha() {
        String generateCaptcha = generateCaptcha();
        System.out.println("Capcha : " + generateCaptcha);
        String capcha;
        String capchaMessage;
        while (true) {
            System.out.print(message.getString("enterCaptcha"));
            capcha = scanner.nextLine();
            capchaMessage = checkCaptcha(capcha, generateCaptcha);
            
            //kiem tra loi khi nhap captcha
            if (capchaMessage != null) {
                System.out.println(capchaMessage);
            } else {
                return capcha;
            }
        }
    }

    /**
     * xu li qua trinh dang nhap de hop le
     */
    public void login() {
        String account = inputAccount();
        String password = inputPassword();
        String captcha = inputCaptcha();
        System.out.println(message.getString("loginSuccess"));
    }

    /**
     * xac thuc dau vao so nguyen trong mot pham vi 
     * @param min
     * @param max
     * @return 
     */
    public int checkInputIntLimit(int min, int max) {
        while (true) {
            try {
                int result = Integer.parseInt(scanner.nextLine());
                if (result < min || result > max) {
                    throw new NumberFormatException();
                }
                return result;
            } catch (NumberFormatException e) {
                System.out.println(message.getString("errorCheckInputIntLimit"));
                System.out.println();
            }
        }
    }

}
