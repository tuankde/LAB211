package EBank;

import java.util.Locale;

public class Main {

    public static void main(String[] args) {
        Manager eBank = new Manager();
        System.out.println("-----Login Program-----");
        System.out.println("1. Vietnamese");
        System.out.println("2. English");
        System.out.println("3. Exit");
        System.out.print("Please choice one option: ");
        Locale vietnamese = new Locale("VI");
        Locale english = new Locale("EN");
        int choice = eBank.checkInputIntLimit(1, 2);
        switch (choice){
            case 1 :
                eBank.setLocale(vietnamese);
                eBank.login();
                break;
            case 2:
                eBank.setLocale(english);
                eBank.login();
                break;
            case 3:
                return;
        }
    }
    
}
