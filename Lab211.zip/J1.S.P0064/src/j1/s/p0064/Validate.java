package j1.s.p0064;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Validate {

    //doc du lieu dau vao
    Scanner scanner = new Scanner(System.in);
    
    //dinh dang so dien thoai 1 chuoi co 10 chu so 
    String PHONE_VALID = "^[0-9]{10}$";
    
    //dinh dang email 1 chuoi  la dia chi hop le hay khong
    String EMAIL_VALID = "^[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}$";

    /**
     * kiem tra du lieu nhap vao
     *
     * @return
     */
    public String checkString() {
        String input;
        do {
            input = scanner.nextLine().trim();

            //neu trong thi bao loi và nhac nhap lại
            if (input.isEmpty()) {
                System.err.println("Input must not be empty. Please try again.");
            } else {
                return input;
            }
        } while (true);
    }

    /**
     * kiem tra so dien thoai
     *
     * @return
     */
    public String checkPhone() {
        String inputPhone;
        do {
            inputPhone = checkString();
            
            //neu khong khop yeu cau nguoi dung nhap lai
            if (!inputPhone.matches(PHONE_VALID)) {
                System.err.println("Phone number must be 10 digits. Please try again.");
            } else {
                return inputPhone;
            }
        } while (true);
    }

    /**
     * kiem tra ngay
     *
     * @return
     */
    public String checkDate() {
        while (true) {
            try {
                String dateCheck = checkString();

                //tao doi tuong SimpleDateFormat
                SimpleDateFormat format = new SimpleDateFormat("dd/mm/yyyy");
                
                //kiem tra ngay thang chuan
                format.setLenient(false);
                Date date = format.parse(dateCheck);
                return dateCheck;
            } catch (ParseException e) {
                System.err.println("Invalid date format. Enter the correct format (dd/mm/yyyy)");
            }
        }
    }

    /**
     * xac thuc dai chi Email
     *
     * @return
     */
    public String checkEmail() {
        while (true) {
            String emailCheck = checkString();

            //neu khong chuan form thi nhap lai
            if (!emailCheck.matches(EMAIL_VALID)) {
                System.err.println("Email must be in the correct format. Please try again.");
            } else {
                return emailCheck;
            }
        }
    }
}
