package j1.s.p0064;

/**
 * hien thi
 * 
 * @version 
 * @author Acer
 */
public class Main {

    public static void main(String[] args) {
        Validate val = new Validate();
        System.out.print("Phone number: ");
        String phone = val.checkPhone();
        System.out.print("Email: ");
        String email = val.checkEmail();
        System.out.print("Date: ");
        String date = val.checkDate();
    }
}
