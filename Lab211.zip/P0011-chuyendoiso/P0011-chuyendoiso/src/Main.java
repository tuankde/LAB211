

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Quyen
 */
public class Main {

    public static void main(String[] args) {
        int choice;
        String binary;
        String decimal;
        String hexaDecimal;
        do {
            System.out.println("======Program Change Base number system=====");
            System.out.println("1.The binary number system.");
            System.out.println("2.The decimal number system.");
            System.out.println("3.The hexadecimal number system.");
            System.out.println("4.Exit");
            choice = Validation.checkRange(1, 4, "Enter base system: ");
            switch (choice) {
                case 1:
                    binary = methods.enterBinary();
                    methods.menuConvert("binary", "decimal", "hexadecimal");
                    methods.chooseConvert(2, binary);
                    break;
                case 2:
                    decimal = methods.enterDecimal();
                    methods.menuConvert("decimal", "binary", "hexadecimal");
                    methods.chooseConvert(10, decimal);
                    break;
                case 3:
                    hexaDecimal = methods.enterHexaDecimal();
                    methods.menuConvert("hexa", "binary", "decimal");
                    methods.chooseConvert(16, hexaDecimal);
                    break;
            }
        } while (!(choice == 4));
    }
    
}
