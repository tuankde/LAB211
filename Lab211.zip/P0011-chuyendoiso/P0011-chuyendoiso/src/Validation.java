
import java.util.Scanner;

public class Validation {

    public static Scanner sc = new Scanner(System.in);
    public static final String bina = "[0-1]*";
    public static final String deci = "[0-9]*";
    public static final String hexa = "[0-9A-F]*";

    public static int checkRange(int min, int max, String msg) { 
        int result;
        while (true) {
            System.out.print(msg);
            try {
                result = Integer.parseInt(sc.nextLine());
                if (result < min || result > max) {
                    throw new Exception();
                }
                return result;
            } catch (Exception e) {
                System.out.println("Enter again int in range [" + min + "; " + max + "]");
            }
        }
    }

    public static String checkString() {
        while (true) {
            String s = sc.nextLine();
            if (s.isEmpty()) {
                System.out.println("Input is nothing!");
                System.out.println("Enter again!");
            } else {
                return s;
            }
        }
    }

    public static String checkBinary() {
        while (true) {
            System.out.print("Enter Binary: ");
            String bin = checkString();
            if (bin.matches(bina)) {
                return bin;
            } else {
                System.out.println("Input is 0 or 1!");
            }
        }
    }
    public static String checkDecimal(){
        while (true) {
            System.out.print("Enter decimal: ");
            String dec = checkString();
            if (dec.matches(deci)) {
                return dec;
            }
            else{ System.out.println("Input is 0-9");} 
        }
    }
      public static String checkHexa(){
        while (true) {
            System.out.print("Enter hexa: ");
            String hex = checkString();
            if (hex.matches(hexa)) {
                return hex;
            }
            else{ System.out.println("Input is 0-9 or A-F");} 
        }
    }  
}
