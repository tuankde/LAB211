
public class methods {

    public static char[] hexDigits = {'0', '1', '2', '3', '4', '5', '6', '7', '8',
        '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    public static void menu() {
    }

    //display choose conversion
    public static void menuConvert(String from, String toCase1, String toCase2) {
        System.out.println("1. Convert form " + from + " to " + toCase1);
        System.out.println("2. Convert form " + from + " to " + toCase2);
    }

    //display choose conversion
    public static void chooseConvert(int base, String number) {
        int choice;
        choice = Validation.checkRange(1, 2, "Enter your choice: ");

        if (base == 2) {
            switch (choice) {
                case 1:
                    System.out.println(convertBinaryToDecimal(number));
                    break;
                case 2:
                    System.out.println(convertBinaryToHexa(number));                   
                    break;
            }
        }

        if (base == 10) {
            switch (choice) {
                case 1:
                    System.out.println(convertDecimalToBinary(number));                    
                    break;
                case 2:
                    System.out.println(convertDecimalToHexa(number));                   
                    break;
            }
        }

        if (base == 16) {
            switch (choice) {
                case 1:
                    System.out.println(convertHexaToBinary(number));                   
                    break;
                case 2:
                    System.out.println(convertHexaToDecimal(number));
                    break;
            }
        }
    }

    //base numeral user want to change : the binary number 
    public static String enterBinary() {
        String s = Validation.checkBinary();
        return s;
    }

    //base numeral user want to change : the Decimal number 
    public static String enterDecimal() {
        String s = Validation.checkDecimal();
        return s;
    }

    //base numeral user want to change : the hexadecimal number 
    public static String enterHexaDecimal() {
        String s = Validation.checkHexa();
        return s;
    }

    //allow user convert from binary to decimal
    public static String convertBinaryToDecimal(String binary) {
        char charBina = 0;
        int decimal = 0;
        int pow = 0;
        for (int i = binary.length(); i > 0; i--) {
            charBina = binary.charAt(i - 1);
            for (int j = 0; j < hexDigits.length; j++) {
                if (charBina == hexDigits[j]) {
                    decimal += j * Math.pow(2, pow);
                    pow++;
                }
            }
        }
        return Integer.toString(decimal);
    }

    //allow user convert from binary to hexaDecimal
    public static String convertBinaryToHexa(String binary) {
        String decimal;
        String hexaDecimal = "";
        decimal = convertBinaryToDecimal(binary);
        hexaDecimal = convertDecimalToHexa(decimal);
        return hexaDecimal;
    }

    //allow user convert from hexaDecimal to decimal
    public static String convertHexaToDecimal(String hexaDecimal) {
        int hexa = 0;
        char charHexa;
        int pow = 0;
        for (int i = hexaDecimal.length(); i > 0; i--) {
            charHexa = hexaDecimal.charAt(i - 1);
            for (int j = 0; j < hexDigits.length; j++) {
                if (charHexa == hexDigits[j]) {
                    hexa += j * Math.pow(16, pow);
                    pow++;
                }
            }
        }
        return Integer.toString(hexa);
    }

    //allow user convert from hexaDecimal to Binary
    public static String convertHexaToBinary(String hexaDecimal) {
        String binary;
        String decimal;
        decimal = convertHexaToDecimal(hexaDecimal);
        binary = convertDecimalToBinary(decimal);
        return binary;
    }

    //allow user convert from Decimal to binary
    public static String convertDecimalToBinary(String deci) {
        int decimal;
        String binary = "";
        decimal = Integer.parseInt(deci);
        while (decimal > 0) {
            binary = decimal % 2 + binary;
            decimal /= 2;
        }
        return binary;
    }

    //allow user convert from decimal to hexaDecimal
    public static String convertDecimalToHexa(String deci) {
        String hexaDecimal = "";
        int decimal;
        decimal = Integer.parseInt(deci);
        for (int i = 0; i < hexDigits.length; i++) {
            while (decimal > 0) {
                hexaDecimal = hexDigits[decimal % 16] + hexaDecimal;
                decimal /= 16;
            }
        }
        return hexaDecimal;
    }
}
