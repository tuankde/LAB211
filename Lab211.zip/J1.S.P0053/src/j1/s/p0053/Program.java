/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0053;

import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class Program {

    private static final Scanner sc = new Scanner(System.in);

    /**
     * Hiển thị menu chương trình Bubble Sort.
     *
     * @return Lựa chọn của người dùng (1-4).
     */
    public static int menu() {
        System.out.println("========= Bubble Sort program =========");
        System.out.println("1. Input Element");
        System.out.println("2. Sort Ascending");
        System.out.println("3. Sort Desceding");
        System.out.println("4. Exit.");
        System.out.print("Please choice one option: ");
        //loop until user input correct
        while (true) {
            try {
                int result = Integer.parseInt(sc.nextLine());
                if (result < 1 || result > 4) {
                    throw new NumberFormatException();
                }
                return result;
            } catch (NumberFormatException e) {
                System.err.println("Must be input integer 1 to 4.");
                System.out.print("Enter again: ");
            }
        }
    }

    /**
     * Sắp xếp mảng theo thứ tự tăng dần bằng thuật toán Bubble Sort.
     *
     * @param arr Mảng cần sắp xếp.
     */
    public static void bubbleSortAs(int arr[]) {
        int n = arr.length;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
        System.out.println("----- Ascending -----");
        for (int i = 0; i < arr.length; i++) {
            if (i == arr.length - 1) {
                System.out.print("[" + arr[i] + "]");
                break;
            }
            System.out.print("[" + arr[i] + "]->");
        }
        System.out.println();
    }

    /**
     * Sắp xếp mảng theo thứ tự giảm dần bằng thuật toán Bubble Sort.
     *
     * @param arr Mảng cần sắp xếp.
     */
    public static void bubbleSortDe(int arr[]) {
        int n = arr.length;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] < arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
        System.out.println("----- Descending -----");
        for (int i = 0; i < arr.length; i++) {
            if (i == arr.length - 1) {
                System.out.print("[" + arr[i] + "]");
                break;
            }
            System.out.print("[" + arr[i] + "]<-");
        }
        System.out.println();
    }

    /**
     * Cho phép người dùng nhập số lượng phần tử của mảng.
     *
     * @return Số lượng phần tử nhập bởi người dùng.
     */
    public static int inputSizeOfArray() {
        System.out.println("Input Length Of Arrays");
        System.out.print("Enter number: ");
        //loop until user input correct
        while (true) {
            try {
                int result = Integer.parseInt(sc.nextLine().trim());
                if (result <= 0) {
                    throw new NumberFormatException();
                }
                return result;
            } catch (NumberFormatException e) {
                System.err.println("Please input number greater than zero.");
                System.out.print("Enter again: ");
            }
        }
    }

    /**
     * Cho phép người dùng nhập giá trị của mảng.
     *
     * @return Mảng chứa các giá trị nhập bởi người dùng.
     */
    public static int[] inputValueOfArray() {
        int n = inputSizeOfArray();
        int[] a = new int[n];
        for (int i = 0; i < n; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            a[i] = Validate.checkInputInt();
        }
        return a;
    }
}
