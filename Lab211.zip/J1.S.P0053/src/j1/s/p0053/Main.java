/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0053;

/**
 *
 * @author Acer
 */
public class Main {

    public static void main(String[] args) {
        int[] a = new int[0];
        //loop until user want to exit
        while (true) {
            int choice = Program.menu();
            switch (choice) {
                case 1:
                    a = Program.inputValueOfArray();
                    break;
                case 2:
                    Program.bubbleSortAs(a);
                    break;
                case 3:
                    Program.bubbleSortDe(a);
                    break;
                case 4:
                    System.out.println("Exiting the program.");
                    return;
            }
        }
    }
}
