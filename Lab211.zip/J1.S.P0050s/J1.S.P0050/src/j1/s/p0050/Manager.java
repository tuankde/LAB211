/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0050;

import java.util.*;

/**
 *
 * @author ADMIN
 */
public class Manager {

    //display menu
    public static int DisplayMenu() {
        System.out.println("========= Equation Program =========");
        System.out.println("1. Calculate Superlative Equation");
        System.out.println("2. Calculate Quadratic Equation");
        System.out.println("3. Exit");
        System.out.println("Please choice one option: ");
        int choice = Validation.checkInputIntLimit(1, 3);
        return choice;
    }

    //Print numbers in array and remove comma.
    public static void printNumbers(List<Double> numbers) {
        for (int i = 0; i < numbers.size(); i++) {
            System.out.print(numbers.get(i));
            if (i != numbers.size() - 1) {
                System.out.print(", ");
            }
        }
        System.out.println();

    }

    // Calculate a simple equation
    public static void CalculateEquation() {

        double a = Validation.checkInputDouble("Enter A: ");

        double b = Validation.checkInputDouble("Enter B: ");
        double x = -b / a;
        System.out.printf("Solution: x = %.3f\n", x);

        // Initialize lists to store different types of numbers.
        List<Double> oddNumbers = new ArrayList<>();
        List<Double> evenNumbers = new ArrayList<>();
        List<Double> perfectSquareNumbers = new ArrayList<>();

        //Check if the input and the solution are odd, even, or perfect squares and add them to the respective lists.
        if (Validation.checkOdd(a)) {
            oddNumbers.add(a);
        }
        if (Validation.checkOdd(b)) {
            oddNumbers.add(b);
        }
        if (Validation.checkOdd(x)) {
            oddNumbers.add(x);
        }

        if (Validation.checkEven(a)) {
            evenNumbers.add(a);
        }
        if (Validation.checkEven(b)) {
            evenNumbers.add(b);
        }
        if (Validation.checkEven(x)) {
            evenNumbers.add(x);
        }

        if (Validation.checkSquareNumber(a)) {
            perfectSquareNumbers.add(a);
        }
        if (Validation.checkSquareNumber(b)) {
            perfectSquareNumbers.add(b);
        }
        if (Validation.checkSquareNumber(x)) {
            perfectSquareNumbers.add(x);
        }

        // Print the categorized numbers.
        System.out.print("Number is Odd: ");
        printNumbers(oddNumbers);
        System.out.print("Number is Even: ");
        printNumbers(evenNumbers);
        System.out.print("Number is Perfect Square: ");
        printNumbers(perfectSquareNumbers);
        System.out.println();
    }

    // Calculate a quadratic equation.
    public static void CalculateQuadraticEquation() {
        System.out.println("----- Calculate Quadratic Equation -----");

        double a = Validation.checkInputDouble("Enter A: ");
        double b = Validation.checkInputDouble("Enter B: ");
        double c = Validation.checkInputDouble("Enter C: ");
        double delta = (b * b) - (4 * a * c);
        double x1 = (-b + Math.sqrt(delta)) / (2 * a);
        double x2 = (-b - Math.sqrt(delta)) / (2 * a);
        System.out.printf("Solution: x1 = %.3f and  x2 = %.3f\n ", x1, x2);
        //Initialize  varibles in the list.  
        List<Double> oddNumbers = new ArrayList<>();
        List<Double> evenNumbers = new ArrayList<>();
        List<Double> perfectSquareNumbers = new ArrayList<>();

        // Check if the coefficients and roots are odd, even, or perfect squares and add them to the respective lists.
        if (Validation.checkOdd(a)) {
            oddNumbers.add(a);
        }
        if (Validation.checkOdd(b)) {
            oddNumbers.add(b);
        }
        if (Validation.checkOdd(c)) {
            oddNumbers.add(c);
        }
        if (Validation.checkOdd(x1)) {
            oddNumbers.add(x1);
        }
        if (Validation.checkOdd(x2)) {
            oddNumbers.add(x2);
        }

        if (Validation.checkEven(a)) {
            evenNumbers.add(a);
        }
        if (Validation.checkEven(b)) {
            evenNumbers.add(b);
        }
        if (Validation.checkEven(c)) {
            evenNumbers.add(c);
        }
        if (Validation.checkEven(x1)) {
            evenNumbers.add(x1);
        }
        if (Validation.checkEven(x2)) {
            evenNumbers.add(x2);
        }

        if (Validation.checkSquareNumber(a)) {
            perfectSquareNumbers.add(a);
        }
        if (Validation.checkSquareNumber(b)) {
            perfectSquareNumbers.add(b);
        }
        if (Validation.checkSquareNumber(c)) {
            perfectSquareNumbers.add(c);
        }
        if (Validation.checkSquareNumber(x1)) {
            perfectSquareNumbers.add(x1);
        }
        if (Validation.checkSquareNumber(x2)) {
            perfectSquareNumbers.add(x2);
        }

        // Print the categorized numbers.
        System.out.print("Odd Number(s): ");
        printNumbers(oddNumbers);
        System.out.print("Number is Even: ");
        printNumbers(evenNumbers);
        System.out.print("Number is Perfect Square: ");
        printNumbers(perfectSquareNumbers);
        System.out.println();
    }
}
