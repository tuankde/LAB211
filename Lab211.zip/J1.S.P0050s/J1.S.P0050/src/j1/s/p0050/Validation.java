/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0050;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Validation {

    static Scanner sc = new Scanner(System.in);

    /**
     * kiem tra gia tri nhap vao nam trong khoang nhat dinh
     *
     * @param min
     * @param max
     * @return
     */
    public static int checkInputIntLimit(int min, int max) {
        //loop until user input correct
        while (true) {
            try {
                int result = Integer.parseInt(sc.nextLine().trim());
                if (result < min || result > max) {
                    throw new NumberFormatException();
                }
                return result;
            } catch (NumberFormatException e) {
                System.out.println("Please input number in rage [" + min + ", " + max + "]");
                System.out.print("Enter again: ");
            }
        }
    }

    /**
     * kiem tra gia tri nhap vao kieu double
     *
     * @param msg
     * @return
     */
    public static double checkInputDouble(String message) {
        //loop until user input correct

        while (true) {
            System.out.print(message);
            try {
                double result = Double.parseDouble(sc.nextLine().trim());
                return result;
            } catch (NumberFormatException e) {
                System.out.println("Please input number");
            }
        }
    }

    //check number is odd or not
    public static boolean checkOdd(double n) {
        if (n / 2 != (int) n / 2) {
            return true;
        } else {
            return false;
        }
    }

    //check number is even or not
    public static boolean checkEven(double n) {
        if (n / 2 == (int) n / 2) {
            return true;
        } else {
            return false;
        }
    }

    //check number is squared number or not
    public static boolean checkSquareNumber(double n) {
        if ((int) Math.sqrt(n) * (int) Math.sqrt(n) == (int) n) {
            return true;
        } else {
            return false;
        }
    }
}
