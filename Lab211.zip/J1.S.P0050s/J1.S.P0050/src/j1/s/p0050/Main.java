package j1.s.p0050;

/**
 *
 * @author ADMIN
 */
public class Main {
    public static void main(String[] args) {
        //vong lapde lien tuc hien thi lua chon 
        int choice;
        do {
            choice = Manager.DisplayMenu();
            
            //thuc hien hanh dong
            switch (choice) {
                case 1:
                    Manager.CalculateEquation();
                    break;
                case 2:
                    Manager.CalculateQuadraticEquation();
                    break;
                case 3:
                    System.out.println("Exiting the program.");
                    break;
                default:
                    System.out.println("Invalid choice.Please try again!");
                    break;
            }
        } 
        
        //lap den khi nguoi dung chon thoat
        while (choice != 3);
    }
}
