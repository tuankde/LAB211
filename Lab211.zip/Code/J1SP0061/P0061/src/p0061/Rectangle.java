package p0061;

/**
 * Lớp `Rectangle` mô tả một hình chữ nhật kế thừa từ lớp `Shape`.
 * Hình chữ nhật được xác định bởi chiều rộng (width) và chiều dài (length).
 * Lớp này cung cấp các phương thức để tính diện tích và chu vi của hình chữ nhật.
 */
public class Rectangle extends Shape {

    /** Thuộc tính chiều rộng của hình chữ nhật */
    private double width;

    /** Thuộc tính chiều dài của hình chữ nhật */
    private double length;

    /** Constructor mặc định không có tham số của lớp Rectangle */
    public Rectangle() {

    }

    /** Constructor để khởi tạo một đối tượng Rectangle với chiều rộng và chiều dài đã cho */
    public Rectangle(double width, double length) {
        this.width = width;
        this.length = length;
    }

    /**
     * Phương thức để tính diện tích của hình chữ nhật.
     * @return Diện tích của hình chữ nhật.
     */
    @Override
    public double getArea() {
        return (width * length);
    }

    /**
     * Phương thức để tính chu vi của hình chữ nhật.
     * @return Chu vi của hình chữ nhật.
     */
    @Override
    public double getPerimeter() {
        return 2 * (width + length);
    }

    /**
     * Phương thức in thông tin về hình chữ nhật ra màn hình.
     */
    @Override
    public void printResult() {
        System.out.println("-----Rectangle-----");
        System.out.println("Width: " + width);
        System.out.println("Length: " + length);
        System.out.println("Area: " + getArea());
        System.out.println("Perimeter: " + getPerimeter());
    }
}
