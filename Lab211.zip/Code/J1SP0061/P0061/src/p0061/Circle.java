package p0061;

/**
 * Circle class Lop con cua Shape dai dien cho hinh tron Co r la ban kinh
 * Ghi de getArea(), getPerimeter(), và printResult() de tinh toan va hien thi thong tin hinh tron
 */
public class Circle extends Shape {

    private double r;

    public Circle() {
    }

    public Circle(double r) {
        this.r = r;
    }

    public double getR() {
        return r;
    }

    public void setR(double r) {
        this.r = r;
    }

    //Dien tich hinh tron: Pi * r^2.
    @Override
    public double getArea() {
        return Math.PI * r * r;
    }

    //Chu vi hinh tron: 2 * Pi * r
    @Override
    public double getPerimeter() {
        return Math.PI * 2 * r;
    }
    
    //In thong tin hinh tron
    @Override
    public void printResult() {
        System.out.println("-----Circle-----");
        System.out.println("Radius: " + this.r);
        System.out.println("Area: " + getArea());
        System.out.println("Perimeter: " + getPerimeter());
    }
}
