package p0061;

import java.util.Scanner;

/**
 * Lớp `Main` là lớp chứa phương thức `main` để chạy chương trình tính toán
 * thông tin về các hình học.
 */
public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("=====Calculator Shape Program=====");

        System.out.println("Please input side width of Rectangle: ");
        double width = getInputAndValidate(sc);
        System.out.println("Please input length of Rectangle: ");
        double length = getInputAndValidate(sc);

        System.out.println("Please input radius of Circle: ");
        double radius = getInputAndValidate(sc);

        System.out.println("Please input side A of Triangle: ");
        double sideA = getInputAndValidate(sc);
        System.out.println("Please input side B of Triangle: ");
        double sideB = getInputAndValidate(sc);;
        System.out.println("Please input side C of Triangle: ");
        double sideC = getInputAndValidate(sc);

        // Declare a single object of the abstract Shape class
        Shape shape;

        // Create instances of concrete shapes and assign them to the shape object
        shape = new Rectangle(width, length);
        shape.printResult();

        shape = new Circle(radius);
        shape.printResult();

        shape = new Triangle(sideA, sideB, sideC);
        shape.printResult();

    }

    // Hàm để nhập giá trị và kiểm tra tính hợp lệ
    private static double getInputAndValidate(Scanner sc) {
        double value;
        do {
            String input = sc.next();
            if (Validate.isDouble(input)) {
                value = Double.parseDouble(input);
                if (value > 0) {
                    return value;
                }
            }
            System.err.println("Invalid input. Please enter a positive number.");
        } while (true);
    }

}
