package p0061;

/**
 * Lớp `Shape` là lớp cơ sở trừu tượng mô tả các hình học cơ bản.
 * Lớp này cung cấp phương thức để tính chu vi và diện tích của hình học, và phương thức để in kết quả.
 * Lớp này được thiết kế để đóng gói chung các tính năng chung cho các hình học cụ thể khác.
 */
public class Shape {    
    
    /**
     * Phương thức để tính chu vi của hình học.
     * @return Chu vi của hình học.
     */
    public double getPerimeter() {
        return 0;
    }
    
    /**
     * Phương thức để tính diện tích của hình học.
     * @return Diện tích của hình học.
     */
    public double getArea() {
        return 0;
    }
    
    /**
     * Phương thức để in thông tin về hình học ra màn hình.
     * Phương thức này có thể được ghi đè bởi các lớp con để cung cấp thông tin cụ thể về hình học đó.
     */
    public void printResult() {
    }
}
