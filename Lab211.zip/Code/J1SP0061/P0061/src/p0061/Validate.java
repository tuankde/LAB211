package p0061;

/**
 * Kiem tra du lieu hop le
 */
public class Validate {
    
    /**
     * 
     * @param input chuoi can kiem tra
     * @return true neu chuoi co the chuyen doi thanh so double duong, nguoc lai tra ve false
     */
    public static boolean isDouble(String input) {
        try {
            Double value = Double.parseDouble(input);
            return value > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    
    
    /**
     * 
     * @param a Canh thu nhat cua tam giac
     * @param b Canh thu hai cua tam giac
     * @param c Canh thu ba cua tam giac
     * @return True neu 3 so co the tao thanh 1 tam giac hop le, nguoc lai tra ve False
     */
    public static boolean isTriangle(double a, double b, double c) {
        return a + b > c && a + c > b && b + c > a;
    }
}
