    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
 */
package p0053;

/**
 *
 * @author XuanHuy
 */
public class Main {

    public static void main(String[] args) {
        int[] a = new int[0];
        //loop until user want to exit
        while (true) {
            int choice = P0053.menu();
            switch (choice) {
                case 1:
                    a = P0053.inputValueOfArray();
                    break;
                case 2:
                    P0053.bubbleSortAs(a);
                    break;
                case 3:
                    P0053.bubbleSortDe(a);
                    break;
                case 4:
                    System.out.println("Exiting the program.");
                    return;
            }
        }
    }
}
