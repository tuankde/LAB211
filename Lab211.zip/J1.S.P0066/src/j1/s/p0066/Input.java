package j1.s.p0066;

import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class Input {

    /**
     * Nhập vào và trả về chuỗi đã nhập
     * @param message
     * @return 
     */
    public static String inputString(String message) {
        //nhap từ bàn phím
        Scanner scanner = new Scanner(System.in);
        System.out.print(message);
        
        //đọc chuỗi
        String input = scanner.nextLine();
        return input;
    }

    /**
     * kiểm tra người dùng có muốn tiếp tục hay không
     * @return 
     */
    public static boolean isContinue() {
        String choice;
        while (true) {            
            choice = inputString("Do you want find more?(Y/N): ");
            
            //kiểm tra đầu vào có phải là y or Y or n or N or not
            if (choice.matches("[yYnN]")){
                
                //y or Y return true
                if (choice.equalsIgnoreCase("y")){
                    return true;
                } else {
                    return false;
                }
            }
        }
    }
}
