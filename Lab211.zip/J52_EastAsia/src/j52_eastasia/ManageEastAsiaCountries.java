/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j52_eastasia;

import java.util.*;

/**
 *
 * @author ASUS
 */
public class ManageEastAsiaCountries {
    
    private static Scanner scannerObj = new Scanner(System.in);
    
    /**
     * display menu choice.
     * @return choice.
     */
    public static int menu(){
        System.out.println(Resource.MENU_1);
        System.out.println(Resource.MENU_2);
        System.out.println(Resource.MENU_3);
        System.out.println(Resource.MENU_4);
        System.out.println(Resource.MENU_5);
        System.out.print(Resource.CHOICE);
        int choice = checkInputIntLimit();
        return choice;
    }

    //check user input number limit
    public static int checkInputIntLimit() {
        //loop until user input correct
        while (true) {
            try {
                int result = Integer.parseInt(scannerObj.nextLine().trim());
                if (result < 1 || result > 5) {
                    throw new NumberFormatException();
                    
                }
                return result;
            } catch (NumberFormatException e) {
                System.err.println(Resource.ERROR_1);
                System.out.print(Resource.ENTER_AGAIN);
            }
        }
    }
    
    //check user input string
    public static String checkInputString() {
        //loop until user input correct
        while (true) {
            String result = scannerObj.nextLine().trim();
            if (result.isEmpty()) {
                System.err.println(Resource.ERROR_2);
                System.out.print(Resource.ENTER_AGAIN);
            } else {
                return result;
            }
        }
    }

    //check user input double limit
    public static double checkInputDouble() {
        //loop until user input correct
        while (true) {
            try {
                double result = Double.parseDouble(scannerObj.nextLine());
                return result;
            } catch (NumberFormatException e) {
                System.err.println(Resource.ERROR_3);
                System.out.print(Resource.ENTER_AGAIN);
            }
        }
    }
    
    public static void inputCountry(ArrayList<Country> lc) {
        System.out.print("Enter code of contry: ");
        String countryCode = checkInputString();
        //check code contry exist or not
        if (!checkCountryExist(lc, countryCode)) {
            System.err.println("Country exist.");
            return;
        }
        System.out.print("Enter name of contry: ");
        String countryName = checkInputString();
        System.out.print("Enter total area: ");
        double countryArea = checkInputDouble();
        System.out.print("Enter terrain of contry: ");
        String countryTerrain = checkInputString();
        lc.add(new Country(countryTerrain, countryCode, countryName, countryArea));
        System.out.println("Add successful.");
    }

    //display infomation of country
    public static void printCountry(ArrayList<Country> lc) {
        System.out.printf("%-10s%-25s%-20s%-25s\n", "ID", "Name", "Total Area",
                "Terrain");
        for (Country country : lc) {
            country.display();
        }
    }

    //display infomation sort name in ascending
    public static void printCountrySorted(ArrayList<Country> lc) {
        Collections.sort(lc);
        System.out.printf("%-10s%-25s%-20s%-25s\n", "ID", "Name", "Total Area",
                "Terrain");
        for (Country country : lc) {
            country.display();
        }
    }

    //allow user search infomation contry by name
    public static void searchByName(ArrayList<Country> lc) {
        System.out.print("Enter the name you want to search for: ");
        String countryName = checkInputString();
        System.out.printf("%-10s%-25s%-20s%-25s\n", "ID", "Name", "Total Area",
                "Terrain");
        for (Country country : lc) {
            if (country.getCountryName().equalsIgnoreCase(countryName)) {
                country.display();
            }
        }
    }

    //check country exist by code
    public static boolean checkCountryExist(ArrayList<Country> lc, String countryCode) {
        for (Country country : lc) {
            if (country.getCountryCode().equalsIgnoreCase(countryCode)) {
                return false;
            }
        }
        return true;
    }
    
}

