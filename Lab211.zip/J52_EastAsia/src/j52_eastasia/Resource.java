/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j52_eastasia;

/**
 *
 * @author ASUS
 */
public class Resource {
    //section 1 : label
    public static final String MENU_1 = "1. Enter the information for 11 countries in Southeast Asia.";
    public static final String MENU_2 = "2. Display already information.";
    public static final String MENU_3 = "3. Search the country according to the entered country's name.";
    public static final String MENU_4 = "4. Display the information increasing with the country name.";
    public static final String MENU_5 = "5. Exit.";
    public static final String CHOICE = "Enter your choice :";
    public static final String ENTER_AGAIN = "Enter again :";
    
    //section 2 : message
    public static final String ERROR_1  = "Please input number in rage 1 - 5";
    public static final String ERROR_2  = "Not empty";
    public static final String ERROR_3  = "Please input number double";
    
    
    
}
