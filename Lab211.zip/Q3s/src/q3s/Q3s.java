/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q3s;

/**
 *
 * @author Acer
 */
public class Q3s {

 //LINKLIST
    //1
    void addLast(Person x){ //them vao cuoi ds 1 nut chua noi dung la x
        Node q = new Node(x);
        if (isEmpty()) {
            head = tail = q;
            return;
        }
        tail.next = q;
        tail = q;
    }
    
    void visit(Node p){
        if (p != null){
            System.out.print(p.info);
        }
    }
    
    void traverse(){
        Node p = head;
        while (p != null){
            visit(p);
            p = p.next;
        }
        System.out.println();
    }
    
    void addMany(String[] a, int[] b){
        int n, i;
        n = a.length;
        for (i = 0; i < n; i++) {
            addLast(new Person(a[i], b[i]));
        }
    }
    
    //2
    Node searchByName(String xName){ //tra ve dia chi 
        Node p = head;
        while (p != null){
            if (p.info.name.equals(xName)){
                return p;
            }
            p = p.next;
        }
        return null;
    }
    
    Node searchByAge(int xAge){ //phuong thuc
        Node p = head;
        while (p != null){
            if(p.info.age == xAge){
                return p;
            }
            p = p.next;
        }
        return null;
    }
    
    //3
    void addFirst(Person x){
        head = new Node(x, head);
    }
    
    //4
    void insertAfter(Node q, Person x){ //Chen 1 nut voi dung x vao sau nut q
        if (isEmpty() || q == null){
            return;
        }
        Node q1 = q.next; //cho q1 giu dia chi cua nut sau nut q
        Node p = new Node(x, q1);
        q.next = p;
        if (tail == q){
            tail = p;
        }
    }
    
    //5
    void insertBefore(Node q, Person x){
        if (isEmpty() || q == null){
            return;
        }
        if (q == head){
            addFirst(x);
            return;
        }
        Node f = head;
        while (f != null && f.next != q){
            f = f.next; //sau vong nay f tro vao nut truoc nut q
        }
        if( f == null){
            return; //q khong co trong ds
        }
        insertAfter(f, x); //chen vao sau f, tuc la truoc q
    }
    
    //6
    void removeFisrt(){
        if (isEmpty()){
            return;
        }
        head = head.next;
        if (head == null){
            tail = null;
        }
    }
    
    void remove(Node q){
        if (isEmpty() || q == null){
            return;
        }
        if (q == head){
            removeFisrt();
            return;
        }
        Node f = head;
        while (f != null && f.next != q){
             f = f.next; //sau vong nay f tro vao nut truoc nut q
        }
        if( f == null){
            return; //q khong co trong ds
        }
        Node q1 = q.next; //cho q1 tro vao nut sau nut q
        f.next = q1; //f se tro vao nut truoc q1
        if (f.next == null){
            tail = f;
        }
    }
    
    //7
    void remove(String xName){
        Node q = searchByName(xName);
        remove(q);
    }
    
    //8
    void remove(int xAge){
        Node q = searchByAge(xAge);
        remove(q);
    }
    
    //9
    void removeAll(int xAge){
        Node q;
        while (true) {            
            q = searchByAge(xAge);
            if (q == null){
                break;
            }
            remove(q);
        }
    }
    
    //10
    Node pos(int k){ //Tim dia chi cua phan tu co chi so k
        int i = 0;
        Node p = head;
        while (p != null){ //khi chu het ds
            if (i == k){ //neu da den phan tu thu k
                return (p);
            }
            i++;
            p = p.next;
        }
        return null;
    }
    
    //11
    void removePos(int k){
        Node q = pos(k);
        remove(q);
    }
    
    //12
    void sortByAge(){
        Node pi, pj;
        Person x;
        pi = head;
        while (pi != null){//khi chu het ds
            pj = pi.next; //cho pj di sau pi
            while (pj != null){
            if (pj.info.name.compareTo(pi.info.name) < 0){
                //swap
                x = pi.info;
                pi.info = pj.info;
                pj.info = x;
            }
            pj = pj.next;
            }
            pi = pi.next;
        }
    }
    
    //14
    int size(){  //dem so phan tu
        int i = 0;
        Node p = head;
        while (p != null){
            i++;
            p = p.next;
        }
        return i;
    }
    
    //15
    Person[] toArray(){
        int i, n;
        n = size();
        Person [] a = new Person[n];
        Node p = head;
        i = 0;
        while(p != null){
            a[i++] = new Person(p.info.name, p.info.age);
            //i++;
            p = p.next;
        }
        return a;
    }
    
    //16
    void reverse(){
        MyList1 t = new MyList1(); //Tao 1 ds moi
        Node p = head;
        while (p != null){
            t.addFirst(new Person(p.info.name, p.info.age));
            p = p.next;
        }
        head = t.head;
        tail = t.tail;
    }
    
    //17
    Node findMaxAge(){
        if(isEmpty()){
            return null;
        }
        
        int x;
        Node p, q;
        p = q = head;
        x = head.info.age;
        p = p.next;
        while (p != null){
            if (p.info.age > x){
                x = p.info.age;
                q = p;
            }
            p = p.next;
        }
        return q;
    }
    
    //18
    Node findMinAge(){
        if (isEmpty()){
            return null;
        }
        
        int x;
        Node p, q;
        p = q = head;
        x = head.info.age;
        p = p.next;
        while(p != null){
            if(p.info.age < x){
                x = p.info.age;
                q = p;
            }
            p = p.next;
        }
        return q;
    }
    
    //19
    void setData(Node p, Person x){ //do noi dung vao nut tro boi p
        if (p != null){
            p.info = x;
        }
    }
    
    //20
    void sortByAge(int k, int h){ //sap xep doan tu vi tri thu k den vi tri h
        if (k > h){
            return;
        }
        if (k < 0){
            k = 0;
        }
        int n = size(); //n la so phan tu trong toan ds
        if (h > n-1){
            h = n - 1;//h-1 la chi so cua phan tu cuoi
        }
        Node u = pos(k);//cho con tro u giu dia chi cua phan tu thu k
        Node v = pos(h + 1); //v giu dia chi cua phan tu h+1
        Node pi, pj;
        Person x;
        pi = u;
        while (pi != v){//khi pi chua ra ngoai doan
            pj = pi.next;
            while (pj != v){
                if(pj.info.age < pj.info.age){
                    x = pi.info;
                    pi.info = pj.info;
                    pj.info = x;
                } 
                pj = pj.next;
            }
            pi = pi.next;
        }
    }
    
    //21
    void reverse(int k, int h){
        if(k > h){
            return;
        }
        
        int n = size();
        int i, j;
        if (k < 0 || h > n -1){
            return;
        }
        Person[] a = toArray();
        i = k;
        j = h;
        Person x;
        while (i < j){
            x = a[i];
            a[i] = a[j];
            a[j] = x;
            i++;
            j--;
        }
        clear();
        for (i = 0; i < n; i++) {
            addLast(a[i]);
        }
    }
    
    //BSTree
    Node root;

    public BSTree() {
        root = null;
    }
    
    void clear() {
        root = null;
    }
    
    boolean isEmpty() {
        return root == null;
    }
    
    void insert(int x) {
        Node q = new Node(x);
        if (isEmpty()) {
            root = q;
            return;
        }
        Node p = root, f = null;
        while (p != null) {
            if (p.info == x) 
                return;
            
            f = p;
            if (p.info > x) 
                p = p.left;
            else
                p = p.right;
        }
        
        if (f.info > x) 
            f.left = q;
        else
            f.right = q;
    } 
    
    void preOrder(Node p) {
        if (p == null) return;
        System.out.print(p.info + " ");
        preOrder(p.left);
        preOrder(p.right);
    }
    
    void preOrder() {
        preOrder(root);
        System.out.println();
    }
    
    void inOrder(Node p) {
        if (p == null) return;
        inOrder(p.left);
        System.out.print(p.info + " ");
        inOrder(p.right);
    }
    
    void inOrder() {
        inOrder(root);
        System.out.println();
    }
    
    void postOrder(Node p) {
        if (p == null) return;
        postOrder(p.left);
        postOrder(p.right);
        System.out.print(p.info + " ");
    }
    
    void postOrder() {
        postOrder(root);
        System.out.println();
    }
    
    void BFS() {
        if (isEmpty()) return;
        MyQueue q = new MyQueue();
        q.enqueue(root);
        Node p;
        while (!q.isEmpty()) {
            p = q.dequeue();
            System.out.print(p.info + " ");
            if (p.left != null)
                q.enqueue(p.left);
            if (p.right != null)
                q.enqueue(p.right);
        }
        System.out.println();
    }
    
    void delete(Node x) {
        if (isEmpty()) 
            return;
        Node p = root, f = null;
        while (p != null) {
            if (p.info == x.info) break;
            f = p;
            if (p.info > x.info)
                p = p.left;
            else
                p = p.right;
        }
        if (p == null) return;
        
        // No child
        if (p.left == null && p.right == null) {
            if (f == null) {
                root = null;
                return;
            }
            if (f.left == p)
                f.left = null;
            else
                f.right = null;
        }
        
        // 1 child
        if (p.left != null && p.right == null) {
            if (f == null) {
                root = p.left;
                return;
            }
            if (f.left == p)
                f.left = p.left;
            else
                f.right = p.left;
        } 
        else if (p.left == null && p.right != null) {
            if (f == null) {
                root = p.right;
                return;
            }
            if (f.left == p) 
                f.left = p.right;
            else 
                f.right = p.right;
        }

        // 2 children
        if (p.left != null && p.right != null)
            deleteByCopying(p);
//            deleteByMerging(p);
    }
    
    void deleteByCopying(Node p) {
        Node rightMost = p.left, f = null;
        while (rightMost.right != null) {
            f = rightMost;
            rightMost = rightMost.right;
        }
        p.info = rightMost.info;
        if (f == null)
            p.left = rightMost.left;
        else 
            f.right = rightMost.left;
    }
    
    void deleteByMerging(Node p) {
        Node rightMost = p.left, f = searchParent(p);
        while (rightMost.right != null) rightMost = rightMost.right;
        rightMost.right = p.right;
        if (f == null)
            root = p.left;
        else if (f.left == p)
            f.left = p.left;
        else 
            f.right = p.left;
    }
    
    int height() {
        return height(root);
    }
    
    int height(Node p) {
        if (p == null) return 0;
        int l = height(p.left), r = height(p.right);
        return (l > r) ? l + 1 : r + 1;
    }
    
    boolean isAVL(Node p) {
        if (p == null) 
            return true;
        if (Math.abs(height(p.left) - height(p.right)) <= 1) 
            return isAVL(p.left) && isAVL(p.right);
        return false;
    }
    
    Node updateAVL(Node p) {
        if (p == null)
            return null ;
        while (height(p.left) - height(p.right) > 1) {
            p = rotateRight(p);
            p.left = updateAVL(p.left);
            p.right = updateAVL(p.right);
        }
        while (height(p.right) - height(p.left) > 1) {
            p = rotateLeft(p);
            p.left = updateAVL(p.left);
            p.right = updateAVL(p.right);
        }
        return p;
    }
    
    int count() {
        return count(root);
    }
    
    int count(Node p) {
        return (p == null) ? 0 : 1 + count(p.left) + count(p.right);
    }
    
    int min() {
        if (isEmpty()) return 0;
        Node p = root;
        while (p.left != null) p = p.left;
        return p.info;
    }
    
    Node search(Node x) {
        Node p = root;
        while (p != null && p.info != x.info) {
            if (p.info > x.info)
                p = p.left;
            else
                p = p.right;
        }
        return p;
    }
    
    Node searchParent(Node a) {
        if (a == null)
            return null;
        Node p = root, f = null;
        while (p != null && p != a) {
            f = p;
            if (p.info > a.info)
                p = p.left;
            else 
                p = p.right;
        }
        return f;
    }
    
    Node rotateLeft(Node a) {
        if (a == null || a.right == null)
            return a;
        Node b = a.right;
        a.right = b.left;
        b.left = a;
        return b;
    }
    
    void rotateLeftModifier(Node a) {
        Node p = search(a);
        if (p == root) {
            root = rotateLeft(root);
        } else {
            Node parent = searchParent(p);
            Node b = rotateLeft(p);
            if (p != null) {
                if (parent.left == p)
                    parent.left = b;
                else
                    parent.right = b;
            }
        }
    }
    
    Node rotateRight(Node a) {
        if (a == null || a.left == null)
            return a;
        Node b = a.left;
        a.left = b.right;
        b.right = a;
        return b;
    }
    
    void rotateRightModifier(Node a) {
        Node p = search(a);
        if (p == root) {
            root = rotateRight(root);
        } else {
            Node parent = searchParent(p);
            Node b = rotateRight(p);
            if (p != null) {
                if (parent.left == p)
                    parent.left = b;
                else
                    parent.right = b;
            }
        }
    }
    
    void simpleBalance() {
        if (!isAVL(root)) balance(root);
    }
    
    void balance(ArrayList<Node> a, int first, int last){
        if(first > last) return;
        int m = (first + last) /2;
        int x = ((Node)a.get(m)).info;
        insert(x);
        balance(a, first, m-1);
        balance(a, m+1, last);
    }
	
    void balance(Node p){
        ArrayList<Node> a = new ArrayList<>();
        buildArray(a, p);
        int first = 0;
        int last = a.size() - 1;
        MyTree b = new MyTree();
        b.balance(a, first, last);
        root = b.root;
    } 
    
    void buildArray(ArrayList<Node> a, Node p){
        if (p == null) return;
        buildArray(a, p.left);
        a.add(p);
        buildArray(a, p.right);
    }
    
    //q1
    //replace thang lon thu n
    int MaxAgeN(int n) {
        Node p = head;
        int max = -1;
        if (n == 1) {
            max = p.info.type;
            while (p.next != null) {
                if (p.next.info.type > max) {
                    max = p.next.info.type;
                }
                p = p.next;
            }
        }
        else {
            p = head;
            int maxN = MaxAgeN(n-1);
            while(p!=null) {
                if (p.info.type<maxN) {
                    max = p.info.type;
                }
                p=p.next;
            }
            p=head;
            while (p.next != null) {
                if (p.next.info.type > max && p.next.info.type<maxN) {
                    max = p.next.info.type;
                }
                p = p.next;
            }
        }
        return max;
    }
    void max1(){
        int max = MaxAgeN(2);//edit here
        Node p = head;
        while(p!= null){
            if(max == p.info.type){
                p.info.place ="YY"; //edit here
                break;
            }
            p = p.next;
        }
    }

---------------------------------
   void addLast(Castor x) {//You should write here appropriate statements to complete this function.
        Node q = new Node(x);
        if (isEmpty()) {
            head = tail = q;
        } else {
            tail.next = q;
            tail = q;
        }
    }

 void addLast(String xOwner, int xPrice)
   {//You should write here appropriate statements to complete this function.
    if(xOwner.charAt(0)=='B' || xPrice>100) return;
    Car x = new Car(xOwner,xPrice);
    addLast(x);
   }

---------------------
 void addFirst(Castor x){
       head = new Node(x,head);
       if(tail==null) tail=head;
     }

//---------------
 void addFirst(Castor x) {
        Node p = new Node(x);
        if (isEmpty()) {
            head = tail = p;
            return;
        }
        p.next = head;
        head = p;
    }


---------------------
    void addAfter(Node p, Castor x) {
        Node p1 = new Node(x);
        if (isEmpty()) {
            return;
        }
        p1.next = p.next;
        p.next = p1;
        if (p == tail) {
            tail = p1;
        }
    }
------------------
    void insert(Castor x, int index) {
        int count = 0;
        Node p = head;
        while (p.next != null) {
            if (index == 0) {
                this.addFirst(x);
                break;
            }
            if (count == index - 1) {
                this.addAfter(p, x);
                break;
            }
            count++;
            p = p.next;
        }
    }

------------------

    int max()
        {Node p=head;
        int max=head.info.depth;
        while(p!=null){
            if(max<p.info.depth) max=p.info.depth;
           p=p.next;
         }
        return max;
     }
 -----------------------------
//sort 

void sort(int startIndex, int endIndex) {       
        int count = 0,m=0;
        Castor tmp;
        Node p = head,i;
        while (p.next != null) {
            if (count == startIndex) {
                for (; p != null; p = p.next) {
                    int n=0;
                    for (i = p.next; i != null; i = i.next) {
                        if (p.info.type > i.info.type) {
                            tmp = p.info;
                            p.info = i.info;
                            i.info = tmp;
                        }
                        n++;
                        if (m+n==endIndex-startIndex) {
                            break;
                        }
                    }
                    if (m+1==endIndex-startIndex) {
                        break;
                    }
                    m++;
                }
                break;
            }
            count++;
            p = p.next;
        }
    }

---------------------------------
  void dele(Node q) {
        Node f, p;
        f = null;
        p = head;
        while (p != null) {
            if (p == q) {
                break;
            }
            f = p;
            p = p.next;
        }
        if (p == null) {
            return;//q is not found
        }
        if (f == null) {
            head = head.next;
            if (head == null) {
                tail = null;
            }
            return;
        }
        f.next = p.next;
        if (f.next == null) {
            tail = f;
        }
    }

    void dele(int xPrice) {
        int j = 0;
        Node p = head;
        while (p != null) {
            if (p.info.price < xPrice) {
                break;
            }
            p = p.next;
        }
        if (p != null) {
            dele(p);
        }
    }

---------------------  
void sortByPrice() {
        Node pi, pj;
        pi = head;
        while (pi != null) {
            pj = pi.next;
            while (pj != null) {
                if (pi.info.price > pj.info.price) {
                    Car temp = pi.info;
                    pi.info = pj.info;
                    pj.info = temp;
                }
                pj = pj.next;
            }
            pi = pi.next;
        }
    }

//xoa tu duoi len theo gia tri va so luong xoa

 int size() {
        int size = 0;
        Node p = head;
        while (p.next != null) {
            size++;
            p = p.next;
        }
        return size;
    }

   public Node getNode(int k) {
        int c = 0;
        Node p = head;
        while (p != null && c < k) {
            p = p.next;
            c++;
        }
        return p;
    }
    
      void dele(Node q) {
        Node f, p;
        f = null;
        p = head;
        while (p != null) {
            if (p == q) {
                break;
            }
            f = p;
            p = p.next;
        }
        if (p == null) {
            return;//q is not found
        }
        if (f == null) {
            head = head.next;
            if (head == null) {
                tail = null;
            }
            return;
        }
        f.next = p.next;
        if (f.next == null) {
            tail = f;
        }
    }

    public void removeTwoLastNodeCondition() {
        int c = 0;
        int sz = size();
        for (int i = sz - 1; i >= 0; i--) {
            Node p = getNode(i);
            if (p.info.price == 5) {
                c++;
               dele(p);
                if (c >= 1) {
                    break;
                }
            }
        }
    }

-----------------------------//repalce 
 void Replace() {
        int count = 0;
        Node p = head;
        while (p != null) {
            if (p.info.wing < 6) {
                count++;
                if (count == 2) {
                    p.info.rate = 99;
                }
            }
            p = p.next;
        }
    }
--------------------//get tail (index last)
 int indexLast() {
        int index1 = 0;
        Node p = head;
        while (p.next != null) {
            index1++;
            p = p.next;
        }
        return index1;
    }
----------------------------
 int MaxAgeN() {
        Node p = head;

        int index = 0;

        int max = p.info.wing;
        while (p.next != null) {
            if (p.next.info.wing > max) {
                max = p.next.info.wing;
            }
            p = p.next;
        }
        Node p1 = head;
        while (p1.next != null) {
            index++;
            if (p1.info.wing == max) {
                break;
            }
            p1 = p1.next;
        }

        return index;
    }

 //q2
 --Insert
 void insert(Ball x) {
        Node q = new Node(x);
        if (root == null) {
            root = q;
            return;
        }
        Node f, p;
        p = root;
        f = null;
        while (p != null) {
            if (p.info.type == x.type) {
                return;
            }
            if (x.type < p.info.type) {
                f = p;
                p = p.left;
            } else {
                f = p;
                p = p.right;
            }
        }
        if (x.type < f.info.type) {
            f.left = q;
        } else {
            f.right = q;
        }
    }

    void insert(String xMaker, int xType, int xRadius) {
        if (xMaker.charAt(0) == 'B') {
            return;
        }
        Ball x = new Ball(xMaker, xType, xRadius);
        insert(x);
    }

//-----------------------------------

  void postOrder2(Node p, RandomAccessFile f) throws Exception {
        if (p == null) {
            return;
        }
        postOrder2(p.left, f);
        postOrder2(p.right, f);
        //edit here
        if (p.info.radius < 5) {
            fvisit(p, f);
        }
//---------

----------------------
    void inOrder2(Node p, RandomAccessFile f) throws Exception {
        if (p == null) {
            return;
        }
       
        inOrder2(p.left, f);
        if(p.info.price < 7 )
        fvisit(p, f);
        inOrder2(p.right, f);
    }
--------------------
//xoa thang dau tien co 2 con , duyet theo in-order

  int count = 0;

    void inOrder2(Node p, RandomAccessFile f) throws Exception {
        if (p == null) {
            return;
        }
        inOrder2(p.left, f);
        if (p.left != null && p.right != null && count == 0) {
            count++;
            deleByCopy(p.info.type);

        }
        inOrder2(p.right, f);
    }

    void deleByCopy(int xPrice) {
        if (root == null) {
            System.out.println(" The tree is empty, no deletion");
            return;
        }
        Node f, p; // f will be the father of p
        p = root;
        f = null;
        while (p != null) {
            if (p.info.type == xPrice) {
                break;//Found key x
            }
            if (xPrice < p.info.type) {
                f = p;
                p = p.left;
            } else {
                f = p;
                p = p.right;
            }
        }
        if (p == null) {
            System.out.println(" The key " + xPrice + " does not exist, no deletion");
            return;
        }
        if (p.left == null && p.right == null) // p is a leaf node
        {
            if (f == null) // The tree is one node
            {
                root = null;
            } else {
                if (f.left == p) {
                    f.left = null;
                } else {
                    f.right = null;
                }
            }
            return;
        }

        if (p.left != null && p.right == null) // p has only left child
        {
            if (f == null) // p is a root
            {
                root = p.left;
            } else {
                if (f.left == p) // p is a left child
                {
                    f.left = p.left;
                } else {
                    f.right = p.left;
                }
            }
            return;
        }

        if (p.left == null && p.right != null) // p has only right child
        {
            if (f == null) // p is a root
            {
                root = p.right;
            } else {
                if (f.left == p) // p is aleft child
                {
                    f.left = p.right;
                } else {
                    f.right = p.right;
                }
            }
            return;
        }

        if (p.left != null && p.right != null) // p has both left and right children
        {
            Node q, fr, rp; // p's key will be replaced by rp's one
            fr = null;
            q = p.left;
            rp = q;
            while (rp.right != null) {
                fr = rp;
                rp = rp.right; // Find the right most node on the left sub-tree
            }
            p.info = rp.info;
            if (fr == null) // rp is just a left son of p 
            {
                p.left = rp.left;
            } else {
                fr.right = rp.left;
            }
        }

    }
    

//------------------
//Duyet in-order , p co 2 con , xoay trai p

   int count1 = 0;
    void inOrder3(Node p, RandomAccessFile f) throws Exception {
        if (p == null) {
            return;
        }
        inOrder3(p.left, f);
       if (p.left != null && p.right != null && count1 == 0) {
            count1++;
           rotateLeft(p);
         
            
       }
        inOrder3(p.right, f);
    }
    
     Node parent(Node ch) {
        if (ch == root || ch == null) {
            return null;
        }
        Node p = root;
        Node parent = null;
        while (p != null) {
            if (p.info.type == ch.info.type) {
                break;
            }
            parent = p;
            if (p.info.type > ch.info.type) {
                p = p.left;
            } else {
                p = p.right;
            }
        }
        return parent;
    }
     void rotateLeft(Node par) {
        if (par == null || par.right == null) {
            return;
        }
        Node ch = par.right;
        par.right = ch.left;
        ch.left = par;
        if (parent(par) == null) {
            root = ch;
            return;
        }
        if (parent(par).left == par) {
            parent(par).left = ch;
        } else {
            parent(par).right = ch;
        }
    }

//-------------------------
//xoa thang lon thu (count)

    int MaxAgeN(int n) {
        Node p = root;
        int max = -1;
        Queue q = new Queue();
        q.enqueue(root);

        if (n == 1) {
            while (!q.isEmpty()) {
                p = (Node) q.dequeue();
                if (p.info.color > max) {
                    max = p.info.color;
                }
                if (p.left != null) {
                    q.enqueue(p.left);
                }
                if (p.right != null) {
                    q.enqueue(p.right);
                }
            }
        } else {
            p = root;
            int maxN = MaxAgeN(n - 1);
            max = 0;
            while (!q.isEmpty()) {
                p = (Node) q.dequeue();
                if (p.info.color > max && p.info.color < maxN) {
                    max = p.info.color;
                }
                if (p.left != null) {
                    q.enqueue(p.left);
                }
                if (p.right != null) {
                    q.enqueue(p.right);
                }
            }
        }
        return max;
    }
    
    void deleByCopy(int xPrice) {
        if (root == null) {
            System.out.println(" The tree is empty, no deletion");
            return;
        }
        Node f, p; // f will be the father of p
        p = root;
        f = null;
        while (p != null) {
            if (p.info.color == xPrice) {
                break;//Found key x
            }
            if (xPrice < p.info.color) {
                f = p;
                p = p.left;
            } else {
                f = p;
                p = p.right;
            }
        }
        if (p == null) {
            System.out.println(" The key " + xPrice + " does not exist, no deletion");
            return;
        }
        if (p.left == null && p.right == null) // p is a leaf node
        {
            if (f == null) // The tree is one node
            {
                root = null;
            } else {
                if (f.left == p) {
                    f.left = null;
                } else {
                    f.right = null;
                }
            }
            return;
        }
        
        if (p.left != null && p.right == null) // p has only left child
        {
            if (f == null) // p is a root
            {
                root = p.left;
            } else {
                if (f.left == p) // p is a left child
                {
                    f.left = p.left;
                } else {
                    f.right = p.left;
                }
            }
            return;
        }
        
        if (p.left == null && p.right != null) // p has only right child
        {
            if (f == null) // p is a root
            {
                root = p.right;
            } else {
                if (f.left == p) // p is aleft child
                {
                    f.left = p.right;
                } else {
                    f.right = p.right;
                }
            }
            return;
        }
        
        if (p.left != null && p.right != null) // p has both left and right children
        {
            Node q, fr, rp; // p's key will be replaced by rp's one
            fr = null;
            q = p.left;
            rp = q;
            while (rp.right != null) {
                fr = rp;
                rp = rp.right; // Find the right most node on the left sub-tree
            }
            p.info = rp.info;
            if (fr == null) // rp is just a left son of p 
            {
                p.left = rp.left;
            } else {
                fr.right = rp.left;
            }
        }
        
    }
    

//----------------------------
//xoay trai thang parent cua thang lon nhat
   void max2() {
        if (isEmpty()) {
            return;
        }
        Node p = root;
        while (p.right != null) {
            p = p.right;
        }
        rotateL(parent(p));
    }

    public Node rotateL(Node par) {
        if (par == null) {
            return null;
        }
        if (par.left == null) {
            return null;
        }
        Node p = root;
        Node gr = null;
        while (p != null) {
            if (p == par) {
                break;
            }
            gr = p;
            if (p.info.color > par.info.color) {
                p = p.left;
            } else {
                p = p.right;
            }
        }

        Node ch = par.right;
        par.right = ch.left;
        ch.left = par;
        if (gr == null) {
            root = ch;
        } else if (gr.left == p) {
            gr.left = ch;
        } else if (gr.right == p) {
            gr.right = ch;
        }
        return ch;
    }

    Node parent(Node x) {
        Node p = root;
        Node parent = null;
        while (p != null) {
            if (p.info.color == x.info.color) {
                break;
            }
            parent = p;
            if (p.info.color > x.info.color) {
                p = p.left;
            } else {
                p = p.right;
            }
        }
        return parent;
    }  

//--------------------
//xoay phai

public void rotateRight(Node par) {
        Node p = root;
        Node gr = null;
        while (p != null) {
            if (p == par) {
                break;
            }
            gr = p;
            if (p.info.getName().compareToIgnoreCase(par.info.getName()) > 0) {
                p = p.left;
            } else {
                p = p.right;
            }
        }
        if (par.left == null) {
            return;
        }
        Node ch = par.left;
        par.left = ch.right;
        ch.right = par;
        if (gr == null) {
            root = ch;
        } else if (gr.left == p) {
            gr.left = ch;
        } else if (gr.right == p) {
            gr.right = ch;
        }
    }

//----------------
//xoa node thu may

int count2 = 0;

    void preOrder4(Node p, RandomAccessFile f) throws Exception {
        if (p == null) {
            return;
        }
        count2++;
        if (count2 == 4) {
            deleByCopy(p.info.sound);
            return;
        }

        preOrder4(p.left, f);
        preOrder4(p.right, f);
    }
---------------------------
//xoay trai void
 public void rotateL(Node par) {
        
        Node p = root;
        Node gr = null;
        while (p != null) {
            if (p == par) {
                break;
            }
            gr = p;
            if (p.info.sound > par.info.sound) {
                p = p.left;
            } else {
                p = p.right;
            }
        }

        Node ch = par.right;
        par.right = ch.left;
        ch.left = par;
        if (gr == null) {
            root = ch;
        } else if (gr.left == p) {
            gr.left = ch;
        } else if (gr.right == p) {
            gr.right = ch;
        }
        
    }
//Tim thang node thu 2 theo breadth va lay no lam goc , xoa thang lon nhat trong cay subtree do

 void breadth2(Node p, RandomAccessFile f) throws Exception {
        int count = 0;
        if (p == null) {
            return;
        }
        Queue q = new Queue();
        q.enqueue(p);
        Node r;
        while (!q.isEmpty()) {
            r = q.dequeue();
            if (r.left != null) {
                count++;
                if (count == 2) {
                    if (r.left == null && r.right == null) {
                        dele(r.info.depth);
                    } else {
                        dele(MaxN(r, 1)); //r la root cua sub-tree , n la lon thu bao nhieu
                    }
                }
            }
            if (r.left != null) {
                q.enqueue(r.left);
            }
            if (r.right != null) {
                q.enqueue(r.right);
            }
        }
    }

    int MaxN(Node p, int n) {
        int max = -1;
        Queue q = new Queue();
        q.enqueue(p);
        if (n == 1) {
            while (!q.isEmpty()) {
                p = (Node) q.dequeue();
                if (p.info.depth > max) {
                    max = p.info.depth;
                }
                if (p.left != null) {
                    q.enqueue(p.left);
                }
                if (p.right != null) {
                    q.enqueue(p.right);
                }
            }
        } else {
            int maxN = MaxN(p, n - 1);
            max = 0;
            while (!q.isEmpty()) {
                p = (Node) q.dequeue();
                if (p.info.depth > max && p.info.depth < maxN) {
                    max = p.info.depth;
                }
                if (p.left != null) {
                    q.enqueue(p.left);
                }
                if (p.right != null) {
                    q.enqueue(p.right);
                }
            }
        }
        return max;
    }

    void dele(int xDepth) {
        if (isEmpty()) {
            return;
        }
        Node p = root;
        Node parent = null;
        while (p != null) {
            if (p.info.depth == xDepth) {
                break;
            }
            parent = p;
            if (p.info.depth > xDepth) {
                p = p.left;
            } else {
                p = p.right;
            }
        }
        if (p == null) {
            return;
        }
        if (p.left == null && p.right == null) {
            if (parent == null) {
                root = null;
                return;
            }
            if (parent.left == p) {
                parent.left = null;
            } else {
                parent.right = null;
            }
        }
        if ((p.left != null && p.right == null) || (p.left == null && p.right != null)) {
            if (p == root) {
                if (p.left != null) {
                    root = p.left;
                } else {
                    root = p.right;
                }
                return;
            }
            if (parent.left == p) {
                if (p.left != null) {
                    parent.left = p.left;
                } else {
                    parent.left = p.right;
                }
            } else {
                if (p.left != null) {
                    parent.right = p.left;
                } else {
                    parent.right = p.right;
                }
            }
        }
        if (p.left != null && p.right != null) {
            Node rm = p.left;
            Node parentRM = null;
            while (rm.right != null) {
                parentRM = rm;
                rm = rm.right;
            }
            p.info = rm.info;
            if (parentRM == null) {
                p.left = rm.left;
            } else {
                parentRM.right = rm.left;
            }
        }
    }

-------------------------------
//tim thang  thu 2 con co trai duyet theo breath
 void breadth3(Node p, RandomAccessFile f) throws Exception {
        int count3 = 0;
        if (p == null) {
            return;
        }
        Queue q = new Queue();
        q.enqueue(p);
        Node r;
        while (!q.isEmpty()) {
            r = q.dequeue();
            if(r.left != null ){
                
                count3++;
                if(count3 == 2){
                    rotateRight(r);//
                }
            }
            if (r.left != null) {
                q.enqueue(r.left);
            }
            if (r.right != null) {
                q.enqueue(r.right);
            }
        }
    }

----------------------
 public int getHeight(Node p) {
        if (p == null) {
            return 0;
        }
        return Math.max(getHeight(p.left), getHeight(p.right)) + 1;
    }
 
 -------------------//xoa thang cha cua thang node thu 4 duyet theo post-order
	int count2 = 0;
        Node parent(Node x) {
        Node p = root;
        Node parent = null;
        while (p != null) {
            if (p.info.wing == x.info.wing) {
                break;
            }
            parent = p;
            if (p.info.wing > x.info.wing) {
                p = p.left;
            } else {
                p = p.right;
            }
        }
        return parent;
    }  
    
void postOrder2(Node p, RandomAccessFile f) throws Exception {
      if(p==null) return;
      postOrder2(p.left,f);
      postOrder2(p.right,f);
     count2++;
     if(count2 == 4){
         dele(parent(p).info.wing);
     }
     }
    void dele(int xDepth) {
        if (isEmpty()) {
            return;
        }
        Node p = root;
        Node parent = null;
        while (p != null) {
            if (p.info.wing == xDepth) {
                break;
            }
            parent = p;
            if (p.info.wing > xDepth) {
                p = p.left;
            } else {
                p = p.right;
            }
        }
        if (p == null) {
            return;
        }
        if (p.left == null && p.right == null) {
            if (parent == null) {
                root = null;
                return;
            }
            if (parent.left == p) {
                parent.left = null;
            } else {
                parent.right = null;
            }
        }
        if ((p.left != null && p.right == null) || (p.left == null && p.right != null)) {
            if (p == root) {
                if (p.left != null) {
                    root = p.left;
                } else {
                    root = p.right;
                }
                return;
            }
            if (parent.left == p) {
                if (p.left != null) {
                    parent.left = p.left;
                } else {
                    parent.left = p.right;
                }
            } else {
                if (p.left != null) {
                    parent.right = p.left;
                } else {
                    parent.right = p.right;
                }
            }
        }
        if (p.left != null && p.right != null) {
            Node rm = p.left;
            Node parentRM = null;
            while (rm.right != null) {
                parentRM = rm;
                rm = rm.right;
            }
            p.info = rm.info;
            if (parentRM == null) {
                p.left = rm.left;
            } else {
                parentRM.right = rm.left;
            }
        }
    }
===================================================================
Tim node thu 5 khi duyet post-order. Dem so node cua seb-tree = k.
Gan gia tri k cho 1 thuoc tinh

/-----------------------------------------
int count = 0;
    Node node3 = null;

    void postOrder(Node p) {
        if (p == null) {
            return;
        }
        postOrder(p.left);
        postOrder(p.right);
        //logic
        if (count == 4 && node3 == null) {
            node3 = p;
        }
        count++;
    }

    int countNode(Node pNode) {
        if (pNode == null) {
            return 0;
        }
        int k, h, rNode;
        k = countNode(pNode.left);
        h = countNode(pNode.right);
        rNode = k + h + 1;
        return rNode;
    }
/-----------------------------------------
       
//q3
/output D  A  B  E  H  I  C  G  F
//  A  B  E  H  I




    int depthFirst2(boolean visited[], int i, int count, int min, int max, RandomAccessFile f) throws Exception {
        if (count >= min && count <= max) {
            fvisit(i, f);
        }
        visited[i] = true;
        int j;
        for (j = 0; j < n; j++) {
            if (a[i][j] > 0 && (!visited[j])) {
                count = depthFirst2(visited, j, (count + 1), min, max, f);
            }
        }
        return count;
    }

    //k la bat dau tu vetex nao 
    void depthFirst2(int k, int min, int max, RandomAccessFile f) throws Exception {
        int i;
        boolean[] visited = new boolean[20];
        for (i = 0; i < n; i++) {
            visited[i] = false;
        }
        int count = depthFirst2(visited, k, 0, min, max, f);
        for (i = 0; i < n; i++) {
            if (!visited[i]) {
                depthFirst2(visited, i, (count + 1), min, max, f);
            }
        }
        System.out.println();
    }


//-----------------------------------------
//output  B G A E F I C H D
 //  B(1) G(2) A(4) E(3) F(3) I(3) C(1) H(2) D(1)


int deg(int i) {
        int s, j;
        s = 0;
        for (j = 0; j < n; j++) {
            s += a[i][j];
        }
        s += a[i][i];
        return (s);
    }
   
    void fvisit2(int i, RandomAccessFile f) throws Exception {
        f.writeBytes(" " + v[i]+"("+deg(i)+")");
    }

void depth2(boolean[] visited, int k, RandomAccessFile f) throws Exception {
        fvisit2(k, f);
        visited[k] = true;
        for (int i = 0; i < n; i++) {
            if (!visited[i] && a[k][i] > 0) {
                depth2(visited, i, f);
            }
        }
    }

    void depth2(int k, RandomAccessFile f) throws Exception {
        boolean[] visited = new boolean[20];
        int i;
        for (i = 0; i < n; i++) {
            visited[i] = false;
        }
        depth2(visited, k, f);
        for (i = 0; i < n; i++) {
            if (!visited[i]) {
                depth2(visited, i, f);
            }
        }
    }
//--------------------------------------

//Dijktra
//  output A B C E D G

    void dijkstra(int fro, int to, RandomAccessFile f) throws Exception {
        int i, j, k, t, INF;
        INF = 999;
        boolean[] S = new boolean[n];
        int[] d = new int[n];
        int[] p = new int[n];
        for (i = 0; i < n; i++) {
            S[i] = false;
            d[i] = a[fro][i];
            p[i] = fro;
        }

        int[] ss = new int[n];
        int[] pp = new int[n];
        int m, r;

        j = 0;

        // select fro into the set S
        S[fro] = true;
        ss[0] = fro;
        while (true) {
            k = -1;
            t = INF;
            for (i = 0; i < n; i++) {
                if (S[i] == true) {
                    continue;
                }
                if (d[i] < t) {
                    k = i;
                    t = d[i];
                }
            }
            if (k == -1) {
                return; 
            }           
            S[k] = true;
            j++;
            ss[j] = k;
            if (k == to) {
                break;
            }
            // Recalculate d[i]
            for (i = 0; i < n; i++) {
                if (S[i] == true) {
                    continue;
                }
                if (d[i] > d[k] + a[k][i]) {
                    d[i] = d[k] + a[k][i];
                    p[i] = k;
                }
            }
        }
        m = j;
        Stack s = new Stack();
        i = to;
        while (true) {
            s.push(i);
            if (i == fro) {
                break;
            }
            i = p[i];
        }
        j = 0;
        while (!s.isEmpty()) {
            i = s.pop();
            pp[j++] = i;
        }
        r = j;
        f.writeBytes("" + v[pp[0]]);
        for (i = 1; i < r; i++) {
            f.writeBytes(" " + v[pp[i]]);
        }
        f.writeBytes("\r\n");

    }
//-------------------------
//output   E,15 D,19 F,24 G,29
//the last count vertices ....

    void dijkstra2(int fro, int to, int count_index, RandomAccessFile f) throws IOException {
        List<Integer> listSelected = new ArrayList<>();
        int INF = 99;
        boolean[] S = new boolean[n];
        int[] d = new int[n];
        int[] p = new int[n];
        int i, j, k, min;
        for (i = 0; i < n; i++) {
            S[i] = false;
            d[i] = a[fro][i];
            p[i] = fro;
        }
        S[fro] = true;
        listSelected.add(fro);
        while (true) {
            // Find k so that d[k] = min
            min = INF;
            k = -1;
            for (i = 0; i < n; i++) {
                if (S[i]) {
                    continue;
                }
                if (d[i] < min) {
                    min = d[i];
                    k = i;
                }
            }
            if (k == -1) {
                System.out.println("No solution");
                return;
            }
            // select k into the set S
            S[k] = true;
            listSelected.add(k);
            if (k == to) {
                break;
            }
            for (i = 0; i < n; i++) {
                if (S[i]) {
                    continue;
                }
                if (d[i] > d[k] + a[k][i]) {
                    d[i] = d[k] + a[k][i];
                    p[i] = k;
                }
            }
        }
        i = to;
        Stack s = new Stack();
        s.push(i);
        while (true) {
            i = p[i];
            s.push(i);
            if (i == fro) {
                break;
            }
        }

        i = s.pop();
        int mm = listSelected.size() - count_index;
        f.writeBytes("" + v[listSelected.get(mm)] + "," + d[listSelected.get(mm)]);
        for (int m = listSelected.size() - (count_index - 1); m < listSelected.size(); m++) {
            int index = listSelected.get(m);
            f.writeBytes(" " + v[index] + "," + d[index]);
        }
        f.writeBytes("\r\n");
    }

//--------------------------------
//output   A   C   F   E
//  0   9   11   20


 void dijkstra3(int fro, int to, RandomAccessFile f) throws Exception {
        int i, j, k, t, INF;
        INF = 999;
        boolean[] S = new boolean[n];
        int[] d = new int[n];
        int[] p = new int[n];
        for (i = 0; i < n; i++) {
            S[i] = false;
            d[i] = a[fro][i];
            p[i] = fro;
        }

        int[] ss = new int[n];
        int[] pp = new int[n];
        int m, r;
        j = 0;
        S[fro] = true;
        ss[0] = fro;
        while (true) {
            k = -1;
            t = INF;
            for (i = 0; i < n; i++) {
                if (S[i] == true) {
                    continue;
                }
                if (d[i] < t) {
                    k = i;
                    t = d[i];
                }
            }
            if (k == -1) {
                return;
            }
            S[k] = true;
            j++;
            ss[j] = k;
            if (k == to) {
                break;
            }
            for (i = 0; i < n; i++) {
                if (S[i] == true) {
                    continue;
                }
                if (d[i] > d[k] + a[k][i]) {
                    d[i] = d[k] + a[k][i];
                    p[i] = k;
                }
            }
        }
        m = j;
        Stack s = new Stack();
        i = to;
        while (true) {
            s.push(i);
            if (i == fro) {
                break;
            }
            i = p[i];
        }
        j = 0;
        while (!s.isEmpty()) {
            i = s.pop();
            pp[j++] = i;
        }
        r = j;
        f.writeBytes("" + v[pp[0]]);
        for (i = 1; i < r; i++) {
            f.writeBytes("   " + v[pp[i]]);
        }
        f.writeBytes("\r\n");
        f.writeBytes("" + d[pp[0]]);
        for (i = 1; i < r; i++) {
            f.writeBytes("   " + d[pp[i]]);
        }
        f.writeBytes("\r\n");
    }
    
//-------------------

//Euler

 boolean hasIsolated() {
        for (int i = 0; i < n; i++) {
            if (deg(i) == 0) {
                return (true);
            }
        }
        return (false);
    }
    
    boolean isConnected() {
        boolean[] p = new boolean[n];
        int i, j, r;
        for (i = 0; i < n; i++) {
            p[i] = false;
        }
        Stack s = new Stack();
        s.push(0);
        p[0] = true;
        while (!s.isEmpty()) {
            r = s.pop();
            for (i = 0; i < n; i++) {
                if (!p[i] && a[r][i] > 0) {
                    s.push(i);
                    p[i] = true;
                }
            }
        }
        for (i = 0; i < n; i++) {
            if (!p[i]) {
                return (false);
            }
        }
        return (true);
    }
    
    boolean isUnDirected() {
        int i, j;
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                if (a[i][j] != a[j][i]) {
                    return (false);
                }
            }
        }
        return (true);
    }
    
    boolean allDegEven() {
        for (int i = 0; i < n; i++) {
            if (deg(i) % 2 == 1) {
                return (false);
            }
        }
        return (true);
    }
    
    boolean hasEulerCycle() {
        if (!hasIsolated() && isUnDirected() && isConnected() && allDegEven()) {
            return (true);
        } else {
            return (false);
        }
    }
    
    void eulerCycle(int fro, RandomAccessFile f) throws IOException {
        if (!hasEulerCycle()) {
            return;
        }
        int[] eu = new int[100];
        int m, i, j, r;
        Stack s = new Stack();
        s.push(fro);
        j = 0;
        while (!s.isEmpty()) {
            r = s.top();
            for (i = 0; i < n; i++) {
                if (a[r][i] > 0) {
                    break;
                }
            }
            if (i == n) {
                s.pop();
                eu[j++] = r;
                
            } else {
                s.push(i);
                a[r][i]--;
                a[i][r]--;
            }
        }
        m = j;
        for (i = 0; i < m; i++) {
            f.writeBytes(v[eu[i]] + " ");
        }
    }
//-----------------------------------------------------
  int count =0;
  void breadth2(boolean [] en, int i,int min, int max, RandomAccessFile f) throws Exception {
    Queue q = new Queue();
    int r,j;
    q.enqueue(i); en[i]=true;
    while(!q.isEmpty()) {
      r = q.dequeue();
      count++;
        if (count>= min && count <= max) {
            fvisit(r, f);
        }
      for(j=0;j<n;j++) {
        if(!en[j] && a[r][j]>0) {
         q.enqueue(j);en[j]=true;
        }
       }
     }
   }

  void breadth2(int  k,int min,int max, RandomAccessFile f) throws Exception {
    boolean [] en = new boolean[20];
    int i;
    for(i=0;i<n;i++) en[i]=false;
    breadth2(en,k,min,max,f);
    for(i=0;i<n;i++) 
      if(!en[i]) breadth2(en,i,min,max,f);
   }
  //--f1-graph-depthfirst
  int count1=0;
  void depth2(boolean [] visited,int k,int min,int max, RandomAccessFile f) throws Exception {
    count1++;
      if (count1>=min && count1<=max) {
          fvisit(k, f);
      }
    visited[k]=true;
    for(int i=0;i<n;i++) {
      if(!visited[i] && a[k][i]>0) depth2(visited,i,min,max,f);
     }
   }
  void depth2(int k,int min,int max, RandomAccessFile f) throws Exception {
    boolean [] visited = new boolean[20];
    int i;
    for(i=0;i<n;i++) visited[i]=false;
    depth2(visited,k,min,max,f);
    for(i=0;i<n;i++) 
       if(!visited[i]) depth2(visited,i,min,max,f);
   }
    
}
