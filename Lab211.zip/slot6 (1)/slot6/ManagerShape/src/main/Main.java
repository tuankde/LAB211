/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import shape.Circle;
import shape.Rectangle;
import shape.Triangle;
import validate.Validator;

/**
 *
 * @author win
 */
public class Main {

    public static void main(String[] args) {
//        Rectangle rectangle = new Rectangle();
//        Circle circle = new Circle();
//        Triangle triangle = new Triangle();
//        System.out.println("=====Calculator Shape Program=====");
//        rectangle.input();
//        circle.input();
//        triangle.input();
//        System.out.println("-----Rectangle-----");
//        rectangle.printResult();
//        System.out.println("-----Circle-----");
//        circle.printResult();
//        System.out.println("-----Triangle-----");
//        triangle.printResult();
        System.out.println("===Calculator Shape Program===");
        double width, length;
        while (true) {
            width = Validator.getDouble("Please input the width of the Rectangle: ",
                    "Please enter width > 0", "Invalid!", 0, Double.MAX_VALUE);
            length = Validator.getDouble("Please input the length of the Rectangle: ",
                    "Please enter length > 0", "Invalid!", 0, Double.MAX_VALUE);
            if (width <= length) {
                break;
            } else {
                System.out.println("Re-input because width>length");
            }
        }
        double radius = Validator.getDouble("Please input the radius of the Circle:",
                "Please enter radius > 0", "Invalid!", 0, Double.MAX_VALUE);
        double a, b, c;
        while (true) {
            a = Validator.getDouble("Please input side A of the Triangle: ",
                    "Please enter side A > 0", "Invalid!", 0, Double.MAX_VALUE);
            b = Validator.getDouble("Please input side B of the Triangle: ",
                    "Please enter side B > 0", "Invalid!", 0, Double.MAX_VALUE);
            c = Validator.getDouble("Please input side C of the Triangle: ",
                    "Please enter side C > 0", "Invalid!", 0, Double.MAX_VALUE);
            if (a + b > c && b + c > a && a + c > b) {
                break;
            } else {
                System.out.println("Re-input again");
            }
        }
        Rectangle rectangle = new Rectangle(width, length);
        Circle circle = new Circle(radius);
        Triangle triangle = new Triangle(a, b, c);
        System.out.println("-----Rectangle-----");
        rectangle.printResult();
        System.out.println("-----Circle-----");
        circle.printResult();
        System.out.println("-----Triangle-----");
        triangle.printResult();
    }
}
