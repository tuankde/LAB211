/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape;

import validate.Validator;

/**
 *
 * @author win
 */
public class Triangle extends Shape {

    private double a; // Length of side A
    private double b; // Length of side B
    private double c; // Length of side C

    public Triangle() {
    }

    public Triangle(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    @Override
    public double getArea() {
        double p = (a + b + c) / 2;
        return Math.sqrt(p * (p - a) * (p - b) * (p - c));
    }

    @Override
    public double getPerimeter() {
        return a + b + c;
    }
//    public void input() {
//        while (true) {
//            a = Validator.getDouble("Please input side A of the Triangle: ",
//                    "Please enter side A > 0", "Invalid!", 0, Double.MAX_VALUE);
//            b = Validator.getDouble("Please input side B of the Triangle: ",
//                    "Please enter side B > 0", "Invalid!", 0, Double.MAX_VALUE);
//            c = Validator.getDouble("Please input side C of the Triangle: ",
//                    "Please enter side C > 0", "Invalid!", 0, Double.MAX_VALUE);
//            if (a + b > c && b + c > a && a + c > b) {
//                return;
//            } else {
//                System.out.println("Re-input because the sum of any two sides"
//                        + " must be greater than the remaining side.");
//            }
//        }
//    }

    @Override
    public void printResult() {
        System.out.println("Side A: " + this.a);
        System.out.println("Side B: " + this.b);
        System.out.println("Side C: " + this.c);
        System.out.println("Area: " + getArea());
        System.out.println("Perimeter: " + getPerimeter());
    }
}
