/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape;

/**
 *
 * @author win
 */
public abstract class Shape {

    /**
     * An abstract method to calculate the perimeter of the shape.
     *
     * @return The perimeter value of the shape.
     */
    public abstract double getPerimeter();

    /**
     * An abstract method to calculate the area of the shape.
     *
     * @return The area value of the shape.
     */
    public abstract double getArea();

    /**
     * An abstract method to print results related to the shape. Typically, it
     * will print the perimeter and area of the shape.
     */
    public abstract void printResult();
}
