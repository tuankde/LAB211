/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape;

import validate.Validator;

/**
 *
 * @author win
 */
public class Circle extends Shape {

    private double radius;

    public Circle() {
    }

    public Circle(double radius) {
        this.radius = radius;
    }

    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }

    @Override
    public double getPerimeter() {
        return Math.PI * 2 * radius;
    }
//    public void input() {
//        radius = Validator.getDouble("Please input the radius of the Circle:",
//                "Please enter radius > 0", "Invalid!", 0, Double.MAX_VALUE);
//    }

    @Override
    public void printResult() {
        System.out.println("Radius: " + this.radius);
        System.out.println("Area: " + getArea());
        System.out.println("Circumference (Perimeter): " + getPerimeter());
    }
}
