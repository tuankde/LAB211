/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape;

import validate.Validator;

/**
 *
 * @author win
 */
public class Rectangle extends Shape {

    private double width; // Width of the rectangle
    private double length; // Length of the rectangle

    public Rectangle() {
    }

    public Rectangle(double width, double length) {
        this.width = width;
        this.length = length;
    }

    @Override
    public double getArea() {
        return width * length;
    }

    @Override
    public double getPerimeter() {
        return 2 * (width + length);
    }
//    public void input() {
//        width = Validator.getDouble("Please input the width of the Rectangle: ",
//                "Please enter width > 0", "Invalid!", 0, Double.MAX_VALUE);
//        length = Validator.getDouble("Please input the length of the Rectangle: ",
//                "Please enter length > 0", "Invalid!",0, Double.MAX_VALUE);
//    }

    @Override
    public void printResult() {
        System.out.println("Width: " + width);
        System.out.println("Length: " + length);
        System.out.println("Area: " + getArea());
        System.out.println("Perimeter: " + getPerimeter());
    }
}
