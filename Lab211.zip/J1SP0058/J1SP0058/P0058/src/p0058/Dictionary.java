package p0058;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Lớp đại diện cho một từ điển lưu trữ các từ tiếng Anh và bản dịch tiếng Việt tương ứng của chúng.
 */
public class Dictionary {
    
    /**
     * Map để lưu trữ các mục từ điển với các từ tiếng Anh làm key và
     * bản dịch tiếng Việt làm value.
     */
    Map<String, String> dict;
    
    
    /**
     * Constructor cho lớp Dictionary. Tải dữ liệu từ điển từ một
     * tệp khi khởi tạo.
     *
     * @throws IOException nếu có lỗi I/O xảy ra trong quá trình đọc tệp.
     */
    public Dictionary() throws IOException {
        dict = new HashMap<>();
        loadData();
    }
    
    
    /**
     * Tải dữ liệu từ điển từ một tệp. Tệp nên chứa các mục trong
     * định dạng "TừTiếngAnh - BảnDịchTiếngViệt". Mỗi mục sẽ được đọc và
     * thêm vào bản đồ từ điển.
     *
     * @throws IOException nếu có lỗi I/O xảy ra trong quá trình đọc tệp.
     */
    public void loadData() throws IOException {
        File f = new File("dictionary.txt");
        FileReader fr = new FileReader(f);
        BufferedReader br = new BufferedReader(fr);
        while(true) {
            String line = br.readLine();
            if(line == null || line.isEmpty()) {
                break;
            }
            String[] words = line.split("[-]");
            String eng = words[0].trim();
            String vi = words[1].trim();
            dict.put(eng, vi);
        }
        fr.close();
        br.close();
    }
    
    /**
     * Lưu dữ liệu từ điển vào một tệp. Các mục từ điển sẽ được viết
     * vào tệp theo định dạng "TừTiếngAnh - BảnDịchTiếngViệt".
     *
     * @throws IOException nếu có lỗi I/O xảy ra trong quá trình viết tệp.
     */
    public void saveData() throws IOException {
        File f = new File("dictionary.txt");
        FileWriter fw = new FileWriter(f);
        BufferedWriter bw = new BufferedWriter(fw);
        for (Map.Entry<String, String> entry : dict.entrySet()) {
            bw.write(entry.getKey() + " - " + entry.getValue() + "\n");
        }
        bw.close();
        fw.close();
    }
    
    
    /**
     * Thêm một từ vào từ điển. Yêu cầu người dùng nhập một từ tiếng Anh và
     * bản dịch tiếng Việt của nó. Nếu từ tiếng Anh đã tồn tại trong
     * từ điển, yêu cầu người dùng cập nhật bản dịch. Thêm từ vào bản đồ từ điển
     * và lưu dữ liệu vào tệp.
     *
     * @throws IOException nếu có lỗi I/O xảy ra trong quá trình viết tệp.
     */
    public void addWord() throws IOException {
        System.out.println("------------- Add -------------");
        String eng = Validation.getString("Enter English: ");
        if (dict.containsKey(eng) && !Validation.YN(eng + " is already existed in diction ary, do you wnat to update (Y/N)?")) {
            return;
        }
        String vi = Validation.getString("Enter Vietnamese: ");
        dict.put(eng, vi);
        saveData();
        System.out.println("ADD SUCCESSFUL");
    }
    
    
    /**
     * Xóa một từ khỏi từ điển.
     * Yêu cầu người dùng nhập một từ tiếng Anh để xóa.
     * Nếu từ không tồn tại trong từ điển, hiển thị thông báo "KHÔNG TÌM THẤY".
     * Xóa từ khỏi bản đồ từ điển và lưu dữ liệu đã cập nhật vào tệp.
     * @throws IOException nếu có lỗi I/O xảy ra trong quá trình viết tệp.
     */
    public void removeWord() throws IOException {
        System.out.println("------------ Delete ----------------");
        String eng = Validation.getString("Enter English: ");
        if(!dict.containsKey(eng)) {
            System.out.println("Not found");
            return;
        }
        dict.remove(eng);
        saveData();
        System.out.println("REMOVE SUCCESSFULL");
    }
    
    
    /**
     * Dịch một từ tiếng Anh sang tương đương tiếng Việt.
     * Yêu cầu người dùng nhập một từ tiếng Anh.
     * Nếu từ không tồn tại trong từ điển, hiển thị thông báo "KHÔNG TÌM THẤY".
     * In ra bản dịch tiếng Việt tương ứng.
     */
    public void translate() {
        System.out.println("------------- Translate ------------");
        String eng = Validation.getString("Enter English: ");
        if (!dict.containsKey(eng)) {
            System.out.println("NOT FOUND");
            return;
        }
        System.out.println("Vietnamese: " + dict.get(eng));
    }
}
