/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p0058;

import java.io.IOException;

/**
 *
 * @author XuanHuy
 */
public class Main {
    
    /**
     * Mảng các lựa chọn thao tác cho chương trình từ điển.
     */
    private static String[] ops = {
        "Add word",
        "Delete word",
        "Translate word",
        "Exit"
    };
    
     /**
     * Hiển thị menu chính và xử lý đầu vào từ người dùng cho các thao tác từ điển.
     * @throws IOException nếu có lỗi I/O xảy ra trong quá trình thực hiện các thao tác từ điển.
     */
    public static void display() throws IOException {
        Dictionary d = new Dictionary();
        int choice;
        do {
            System.out.println("======== Dictionary program ========");
            for (int i = 0; i < ops.length; i++) {
                System.out.println((i + 1) + ". " + ops[i]);
            }
            choice = Validation.getInt("Enter your choice: ", 1, 4);
            switch (choice) {
                case 1:
                    d.addWord();
                    break;
                case 2:
                    d.removeWord();
                    break;
                case 3:
                    d.translate();
                    break;
                case 4:
                    break;
            }
        } while (choice != ops.length);

    }
    
    
    public static void main(String[] args) throws IOException {
        display();
    }
}
