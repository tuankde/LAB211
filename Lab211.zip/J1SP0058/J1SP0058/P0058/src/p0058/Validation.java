/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p0058;

import java.util.Scanner;

/**
 *
 * @author XuanHuy
 */
public class Validation {

    /**
     * @param args the command line arguments
     */
    private static Scanner sc = new Scanner(System.in);
    
    /**
     * Nhận một số nguyên nằm trong khoảng cụ thể.
     *
     * @param msg Thông báo hiển thị khi yêu cầu nhập.
     * @param min Giá trị tối thiểu cho phép nhập.
     * @param max Giá trị tối đa cho phép nhập.
     * @return Số nguyên đã nhập sau khi kiểm tra.
     */
    public static int getInt(String msg, int min, int max) {
        // Đảm bảo min không lớn hơn max.
        if(min > max) {
            int temp = min;
            min = max;
            max = temp;
        }
        while(true) {
            try {
                System.out.print(msg);
                int n = Integer.parseInt(sc.nextLine());
                if(n >= min && n <= max) {
                    return n;
                }
                System.out.println("PLEASE INPUT IN RANGE [" + min + ", " + max + "]");
            } catch (NumberFormatException e) {
                System.err.println("WRONG FORMAT!!!");
            }
        }
    }
    
    
    /**
     * Nhận một chuỗi không rỗng.
     *
     * @param msg Thông báo hiển thị khi yêu cầu nhập.
     * @return Chuỗi không rỗng sau khi kiểm tra.
     */
    public static String getString(String msg) {
        while(true) {
            System.out.print(msg);
            String s = sc.nextLine();
            if(!s.isEmpty()) {
                return s;
            }
            System.err.println("STRING IS EMPTY!!!");
        }
    }
    
    
    
    /**
     * Nhận câu hỏi có thể trả lời bằng "có" hoặc "không" từ người dùng (true cho có, false cho không).
     *
     * @param msg Thông báo hiển thị khi yêu cầu nhập.
     * @return Câu hỏi có/không để tiếp tục chương trình.
     */
   public static boolean YN(String msg) {
       while(true) {
           System.out.println(msg);
           String s = sc.nextLine();
           if(s.equalsIgnoreCase("y")) {
               return true;
           } else if(s.equalsIgnoreCase("n")) {
               return false;
           }
       }
   }
   
   
}
