/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fibonacci;

/**
 *
 * @author Acer
 */
public class Fibonacci {
    public static int fibo(int n){
        if (n < 2){
            return n;
        } else {
            return fibo(n-2) + fibo(n-1);
        }
    }
    
    
    public static void main(String[] args) {
        System.out.println("The 45 sequence fibonacci:");
        for (int i = 0; i < 43; i++) {
            System.out.print(fibo(i) + ", ");
        }
        System.out.print(fibo(44));
    }
    
}
