/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0065;

/**
 *
 * @author Acer
 */
public class Manager {
    
    /**
     * 
     * @param avg
     * @return 
     */
    public String getType(double avg){
        if (avg > 7.5){
            return "A";
        } else if (avg >= 6){
            return "B";
        } else if (avg >= 4){
            return "C";
        } else 
            return "D";
    }
    
   
}
