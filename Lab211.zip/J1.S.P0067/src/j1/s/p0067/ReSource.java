/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0067;

/**
 *
 * @author Acer
 */
public class ReSource {
    final static String title = "==== Analysis String program ====";
    final static String inputString = "Input String: ";
    final static String numberToCharacter = "\\D+";
    final static String comma = ",";
    final static String squareNumber = "SquareNumbers: ";
    final static String oddNumber = "OddNumbers: ";
    final static String evenNumber = "EvenNumbers: ";
    final static String allNumber = "AllNumbers: ";
    final static String space = " ";
    final static String uppercase = "\\W|[0-9]|[a-z]";
    final static String lowercase = "\\W|[0-9]|[A-Z]";
    final static String special = "\\w";
    final static String allCharacter = "\\W";
    final static String quotes = "";
    final static String Uppercase = "Uppercase: ";
    final static String Lowercase = "Lowercase: ";
    final static String Special = "Special: ";
    final static String AllCharacter = "All Character: ";
}
