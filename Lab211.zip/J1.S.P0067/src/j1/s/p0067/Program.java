
package j1.s.p0067;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * @version 2023 Oct 18
 * @author Acer
 */
public class Program {

    //Nhap chuoi tu ban phim
    private static Scanner scanner = new Scanner(System.in);

    //ham chinh xu li va hien thi
    public static void main(String[] args) {
        System.out.println(ReSource.title);
        System.out.print(ReSource.inputString);
        String input = scanner.nextLine();
        
        //goi phuong thuc xu li so va ki tu
        getNumber(input);
        getCharacter(input);
    }
    
     //kiem tra có phai là squareNumber không
    private static boolean isSquareNumber(int number) {
        if (Math.sqrt(number) * Math.sqrt(number) == number) {
            return true;
        } else {
            return false;
        }
    }
    
    
    /**
     * Xu li va hien thi cac loai so khi nhap vao
     *
     * @param input
     */
    private static void getNumber(String input) {

        //luu tru so theo tung loai
        HashMap<String, ArrayList<Integer>> HashMapNumber = new HashMap<>();

        //thay the ki tu khong phai la so bang dau phay
        String number = input.replaceAll(ReSource.numberToCharacter, ReSource.comma);

        //neu co dau phay o dau thi xoa
        if (number.charAt(0) == ',') {
            number = number.substring(1);
        }

        //neu co dau phay o cuoi thi xoa
        if (number.charAt(number.length() - 1) == ',') {
            number = number.substring(0, number.length() - 1);
        }

        //chia chuoi thanh cac mang so va tinh do dai cua mang
        String[] listNumber = number.split(",");
        int lengthNumber = listNumber.length;

        //tao danh sach cho cac so
        ArrayList<Integer> listSquareNumber = new ArrayList<>();
        ArrayList<Integer> listOddNumber = new ArrayList<>();
        ArrayList<Integer> listEvenNumber = new ArrayList<>();
        ArrayList<Integer> listAllNumber = new ArrayList<>();

        //dua cac so vao danh sach tuong ung
        for (int i = 0; i < lengthNumber; i++) {
            int checkNumber = Integer.parseInt(listNumber[i]);

            //neu la so le thi them vao listOddNumber
            if (checkNumber % 2 == 1) {
                listOddNumber.add(checkNumber);
            }

            //neu la so chan thi them vao listEvenNumber
            if (checkNumber % 2 == 0) {
                listEvenNumber.add(checkNumber);
            }

            //neu la so binh phuong thi them vao listPerfectNumber
            if (isSquareNumber(checkNumber)) {
                listSquareNumber.add(checkNumber);
            }

            //con lai thi them vao danh sach listAllNumber
            listAllNumber.add(checkNumber);
        }

        //dat cac danh sach so vao HashMap
        HashMapNumber.put(ReSource.squareNumber, listSquareNumber);
        HashMapNumber.put(ReSource.oddNumber, listOddNumber);
        HashMapNumber.put(ReSource.evenNumber, listEvenNumber);
        HashMapNumber.put(ReSource.allNumber, listAllNumber);
        
        //hien thi tung danh sach voi cac nhan 
        for (Map.Entry map : HashMapNumber.entrySet()){
            System.out.println(map.getKey() + ReSource.space + map.getValue());
        }
    }
    
    //xu ly va hien thi cac ki tu tu chuoi nhap vao
    private static void getCharacter(String input){
        
        //luu tru ki tu theo tung loai
        HashMap<String, String> hashMapString = new HashMap<>();
        
        //xoa cac ki tu khong phai chu cai hoac so tu chuoi nhap vao
        String uppercase = input.replaceAll(ReSource.uppercase, ReSource.quotes);
        String lowercase = input.replaceAll(ReSource.lowercase, ReSource.quotes);
        String special = input.replaceAll(ReSource.special, ReSource.quotes);
        String allCharacter = input.replaceAll(ReSource.allCharacter, ReSource.quotes);
        
        //dat cac ds ki tu vao HashMap
        hashMapString.put(ReSource.Uppercase, uppercase);
        hashMapString.put(ReSource.Lowercase, lowercase);
        hashMapString.put(ReSource.Special, special);
        hashMapString.put(ReSource.AllCharacter, allCharacter);
        
        //hien thi tung danh sach
        for (Map.Entry map : hashMapString.entrySet()){
            System.out.println(map.getKey() + ReSource.space + map.getValue());
        }
    }
}
