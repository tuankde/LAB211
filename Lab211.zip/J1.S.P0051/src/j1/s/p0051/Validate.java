/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0051;

import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class Validate {

    static Scanner sc = new Scanner(System.in);

    public static int menu() {
        System.out.println("===== Calculator Program ======");
        System.out.println("1. Normal Calculator");
        System.out.println("2. BMI Calculator");
        System.out.println("3. Exit");
        System.out.println("Please choice one option: ");
        int choice = checkInputLimit(1, 3);
        return choice;
    }

    public static int checkInputLimit(int min, int max) {
        while (true) {
            try {
                int result = Integer.parseInt(sc.nextLine());
                if (result < min || result > max) {
                    throw new NumberFormatException();
                }
                return result;
            } catch (NumberFormatException e) {
                System.out.println("Enter again!!!");
            }
        }
    }

    //input number double
    public static double checkInputDouble() {
        while (true) {
            try {
                double result = Double.parseDouble(sc.nextLine());
                return result;
            } catch (NumberFormatException e) {
                System.out.println("Enter again!!!");
            }
        }
    }

    //input operator
    public static String checkInputOperator() {
        String input;
        while (true) {
            input = sc.nextLine().trim();
            if (input.isEmpty()) {
                System.out.println("Enter again!!");
            } else if (input.equalsIgnoreCase("+") || input.equalsIgnoreCase("-")
                    || input.equalsIgnoreCase("*") || input.equalsIgnoreCase("/")
                    || input.equalsIgnoreCase("^") || input.equalsIgnoreCase("=")) {
                return input;
            } else {
                System.out.println("Please input (+, -, *, /, ^)");
            }
            System.out.print("Enter again: ");
        }
    }

    //input number
    public static double inputNumber() {
        System.out.print("Enter number: ");
        double number = checkInputDouble();
        return number;
    }

    //calculator normal
    public static void normalCalculator() {
        double number;
        String operator = checkInputOperator();
        System.out.print("Enter number: ");
        number = checkInputDouble();
        while (true) {
            System.out.print("Enter operator: ");
            if (operator.equalsIgnoreCase("+")) {
                number += inputNumber();
                System.out.println("Memory: " + number);
            }
            if (operator.equalsIgnoreCase("-")) {
                number -= inputNumber();
                System.out.println("Memory: " + number);
            }
            if (operator.equalsIgnoreCase("*")) {
                number *= inputNumber();
                System.out.println("Memory: " + number);
            }
            if (operator.equalsIgnoreCase("/")) {
                number /= inputNumber();
                System.out.println("Memory: " + number);
            }
            if (operator.equalsIgnoreCase("^")) {
                number = Math.pow(number, inputNumber());
                System.out.println("Memory: " + number);
            }
            if (operator.equalsIgnoreCase("=")){
                System.out.println("Result: " + number);
                return;
            }
        }
    }
    
    //display BMI status
    public static String BMIstatus(double bmi){
        if (bmi < 19){
            return "Under standard.";
        } else if (bmi >= 19 && bmi < 25){
            return "Standard.";
        } else if (bmi >= 25 && bmi < 30){
            return "Overweight.";
        } if (bmi > 30){
            return "Very Fast.";
        }
        return null;
    }
}
