/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0010;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class J1SP0010 {

    public static void display(int[] arr){
        System.out.print("[");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]);
            if (i < arr.length - 1){
                System.out.print(", "); 
            }
        }
        System.out.println("]");
    }
    
    public static int[] randomArray(int size){
        Random rd = new Random();
        int[] arr = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = rd.nextInt(size);
        }
        return arr;
    }
    
    public static int linearSearch(int[] arr, int key){
        
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == key){
                return i;
            }
        } 
        return -1;
    }
    
    
    public static void main(String[] args) {
        
        System.out.println("Enter number of array:");
        int n = Validation();
        int arr[] = randomArray(n);
        System.out.println("Enter search value:");
        int value = Validation();
        int index = linearSearch(arr, value);
        System.out.print("The array: ");
        display(arr);
        System.out.println("Found " + value + " at index: " + index);
        
    }
    
    public static int Validation(){
        Scanner sc = new Scanner(System.in);
        int n = 0;
        while (true) {            
            try {
                 n = Integer.parseInt(sc.nextLine());
                if (n > 0){
                    break;
                } else if (n <= 0){
                    System.out.println("Enter again!!!");
                } else {
                    System.out.println("Enter again");
                }
            } catch (NumberFormatException e) {
                System.out.println("Enter again!!!");
            }
        }
        
        return n;
      
    
    }
}
