/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;


import Entity.Doctor;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class Validate {
    
    static Scanner sc = new Scanner(System.in);
    
    //check input number limit
    /**
     * 
     * @param min
     * @param max
     * @return 
     */
    public static int checkInput(int min, int max){
        int input = Integer.parseInt(sc.nextLine());
        while (true) {            
            try {
                
                if (input < min || input > max){
                    throw new NumberFormatException();
                }
                return input;
            } catch (NumberFormatException e) {
                System.out.print("Enter again!!!");
            }
        }
    }
    
    //check input string
    public static String checkInputString(){
        String input = sc.nextLine().trim();
        while (true) {            
            //check String empty or not
            if (input.isEmpty()){
                System.out.print("Enter again!!!");
            } else {
                return input;
            }
        }
    }
    
    //check input int
    public static int checkInputInt(){
        while (true) {            
             try {
                int input = Integer.parseInt(sc.nextLine());
                return input;
            } catch (NumberFormatException e) {
                 System.out.print("Enter again!!!");
            }
        }
    }
    
    //check input yes or no
    public static boolean checkInputYN(){
        while (true) {            
            String input = checkInputString();
            if (input.equalsIgnoreCase("Y")){
                return true;
            }
            if (input.equalsIgnoreCase("N")){
                return false;
            }
            System.out.println("Please input y or n");
            System.out.print("Enter again!!!");
        }
    }
    
    //check code exist or not
    public static boolean checkCodeExist(ArrayList<Doctor> list, String code){
        for (Doctor dt : list){
            if (code.equalsIgnoreCase(dt.getCode())){
                return false;
            }
        }
        return true;
    }
    
    //check doctor duplicate 
    public static boolean checkDuplicate(ArrayList<Doctor> list, String code, String name,
                                            String specialization, int availability){
        for (Doctor dt : list){
            if (code.equalsIgnoreCase(dt.getCode()) && name.equalsIgnoreCase(dt.getName()) 
                && specialization.equalsIgnoreCase(dt.getSpecialization()) 
                && availability == dt.getAvailability()){
                return false;
            }
        }
        return true;
    }
     public static boolean checkChangeInfo(Doctor dt, String code,
            String name, String specialization, int availability) {
        if (dt.getCode().equalsIgnoreCase(code)
                && dt.getName().equalsIgnoreCase(name)
                && dt.getSpecialization().equalsIgnoreCase(specialization)
                && dt.getAvailability() == availability) {
            return false;
        }
        return true;
    }
    
}
