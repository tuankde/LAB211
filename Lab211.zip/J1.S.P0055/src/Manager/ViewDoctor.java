/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;

import Entity.Doctor;
import java.util.ArrayList;

/**
 *
 * @author Acer
 */
public class ViewDoctor {
    //display doctor
    public static int menu(){
        System.out.println("===== Doctor Management =====");
        System.out.println("1. Add Doctor");
        System.out.println("2. Update Doctor");
        System.out.println("3. Delete Doctor");
        System.out.println("4. Search Doctor");
        System.out.println("5. Exit");
        int choice = Validate.checkInput(1, 5);
        return choice;
    }
    
    //user add doctor
    public static void addDoctor(ArrayList<Doctor> list){
        System.out.print("Enter Code: ");
        String code = Validate.checkInputString();
        
        if (!Validate.checkCodeExist(list, code)){
            System.out.println("Code exist.");
            return;
        }
        
        System.out.print("Enter Name: ");
        String name = Validate.checkInputString();
        System.out.print("Enter Specialization: ");
        String specialization = Validate.checkInputString();
        System.out.print("Enter Availability: ");
        int availability = Validate.checkInputInt();
        //check worker duplicate
        if (!Validate.checkDuplicate(list, code, name, specialization, availability)){
            System.out.println("Duplicate.");
            return;
        }
        list.add(new Doctor(code, name, specialization, availability));
        System.out.println("Add successfull!!");
    }
    
    //user update doctor
    public static void update(ArrayList<Doctor> list){
        System.out.print("Enter code: ");
        String code = Validate.checkInputString();
        if (!Validate.checkCodeExist(list, code)){
            System.out.println("Not found doctor.");
        }
        System.out.println("Enter code: ");
        String updateCode = Validate.checkInputString();
        Doctor dl = getDoctorByCode(list, code);
        System.out.print("Enter name: ");
        String name = Validate.checkInputString();
        System.out.print("Enter Specialization: ");
        String specialization = Validate.checkInputString();
        System.out.print("Enter Availability: ");
        int availability = Validate.checkInputInt();
        
        if (!Validate.checkChangeInfo(dl, code, name, specialization, availability)){
            System.out.println("No change");
            return;
        }
        dl.setCode(updateCode);
        dl.setName(name);
        dl.setSpecialization(specialization);
        dl.setAvailability(availability);
        System.out.println("Update Sucessful!");
    }
    
    //user delete doctor
    public static void deleteDoctor(ArrayList<Doctor> list){
        System.out.print("Enter code: ");
        String code = Validate.checkInputString();
        Doctor dt = getDoctorByCode(list, code);
        
        if (dt == null){
            System.out.println("Not found!");
            return;
        } else {
            list.remove(dt);
        }
        System.out.println("Delete Sucessful!!!");
    }
    
    //search doctor
    
    public static void searchDoctor(ArrayList<Doctor> list) {
        System.out.print("Enter name: ");
        String nameSearch = Validate.checkInputString();
        ArrayList<Doctor> listFoundByName = listFoundByName(list, nameSearch);
        if (listFoundByName.isEmpty()) {
            System.err.println("List empty.");
        } else {
            System.out.printf("%-10s%-15s%-25s%-20s\n", "Code", "Name",
                    "Specialization", "Availability");
            for (Doctor doctor : listFoundByName) {
                System.out.printf("%-10s%-15s%-25s%-20d\n", doctor.getCode(),
                        doctor.getName(), doctor.getSpecialization(),
                        doctor.getAvailability());
            }
        }
    }
    
    //get docter by code
    public static Doctor getDoctorByCode(ArrayList<Doctor> list, String code) {
        for (Doctor doctor : list) {
            if (doctor.getCode().equalsIgnoreCase(code)) {
                return doctor;
            }
        }
        return null;
    }
    
    //get list found by name
    public static ArrayList<Doctor> listFoundByName(ArrayList<Doctor> list, String name) {
        ArrayList<Doctor> listFoundByName = new ArrayList<>();
        for (Doctor doctor : list) {
            if (doctor.getName().contains(name)) {
                listFoundByName.add(doctor);
            }
        }
        return listFoundByName;
    }
    
    
}

