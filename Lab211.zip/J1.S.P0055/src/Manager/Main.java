/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;

import Entity.Doctor;
import java.util.ArrayList;

/**
 *
 * @author Acer
 */
public class Main {
    public static void main(String[] args) {
        //them danh sach bac si
        ArrayList<Doctor> list = new ArrayList<>();
        
        // loop until user want exit
        while (true) {    
            int choice = ViewDoctor.menu();
            switch (choice){
                //them bac si
                case 1:
                    ViewDoctor.addDoctor(list);
                    break;
                //update by id
                case 2:
                    ViewDoctor.update(list);
                    break;
                //delete id
                case 3:
                    ViewDoctor.deleteDoctor(list);
                    break;
                //search by text
                case 4:
                    ViewDoctor.searchDoctor(list);
                    break;
                //exit
                case 5:
                    return;
            }
        }
    }
}
