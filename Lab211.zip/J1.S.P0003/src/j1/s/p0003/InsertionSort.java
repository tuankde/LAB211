/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0003;

import java.util.Random;
import java.util.Scanner;

/**
 * 
 * @author Acer
 */
public class InsertionSort {

    /**
     * 
     * @param size
     * @return 
     */
     //random
    public static int[] randomArray(int size){
        Random rd = new Random();
        int[] arr = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = rd.nextInt(10);
        }
        return arr;
    } 
    /**
     * 
     * @param arr 
     */
    //Sort
    static void insertionSortArray(int[] arr) {
        for (int i = 1; i < arr.length; i++) {
            int j = i - 1;
            int val = arr[i];
            while (j >= 0 && arr[j] > val){
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = val;
        }
    }
    /**
     * 
     * @param arr 
     */
    //Display
    public static void display(int[] arr){
        System.out.print("[");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]);
            if (i < arr.length - 1){
                System.out.print(", "); 
            }
        }
        System.out.println("]");
    }
    
    public static void main(String[] args) {
        //Enter size of array
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of array:");
        int n = sc.nextInt(); 
        int[] arr = randomArray(n);
        
        //Display array before
        System.out.print("Unsorted array: ");
        display(arr);
        
        //Sort array
        insertionSortArray(arr);
        
        //Display array after
        System.out.print("Sorted array: ");
        display(arr);
    }
    
}
