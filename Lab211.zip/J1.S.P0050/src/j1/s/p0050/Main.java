/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0050;

/**
 *
 * @author Acer
 */
public class Main {

    public static void main(String[] args) {
        while (true) {            
            int choice = Validate.menu();
            switch (choice){
                case 1:
                    Calculate.superLative();
                    break;
                case 2:
                    Calculate.quadraticEquation();
                    break;
                case 3:
                    return;
            }
        }
    }
    
}
