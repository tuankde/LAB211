/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0050;


/**
 *
 * @author Acer
 */
public class Calculate {
    
    static Validate m = new Validate();
    
    //1
    public static void superLative(){
        System.out.print("Enter A: ");
        double a = m.checkInputDouble();
        System.out.print("Enter B: ");
        double b = m.checkInputDouble();
        double x = -b / a;
        System.out.printf("Solution : x = %.3f\n", x);
        System.out.print("Number is odd: ");
        if (m.checkOdd(a)){
            System.out.print(a + ", ");
        }
        if (m.checkOdd(b)){
            System.out.print(b + ", ");
        }
        if (m.checkOdd(x)){
            System.out.print(x + ", ");
        }
        
        System.out.print("\nNumber is even: ");
        if (m.checkEven(a)){
            System.out.print(a + ", ");
        }
        if (m.checkEven(b)){
            System.out.print(b + ", ");
        }
        if (m.checkEven(x)){
            System.out.print(x + ", ");
        }
        
        System.out.println("\nNumber is Perfect Square: ");
        if (m.checkPerfectNumber(a)){
            System.out.print(a + ", ");
        }
        if (m.checkPerfectNumber(b)){
            System.out.print(b + ", ");
        }
        if (m.checkPerfectNumber(x)){
            System.out.print(x + ", ");
        }
        
    }
    
    //2
    
    public static void quadraticEquation(){
        System.out.print("Enter A: ");
        double a = m.checkInputDouble();
        System.out.print("Enter B: ");
        double b = m.checkInputDouble();
        System.out.print("Enter C: ");
        double c = m.checkInputDouble();
        
        double delta = b * b - 4 * a * c;
        double x1 = (-b + Math.sqrt(delta)) / (2 * a);
        double x2 = (-b - Math.sqrt(delta)) / (2 * a);
        System.out.println("Solution: x1 = " + x1 + " and x2 = " + x2);
        System.out.print("Odd number(s): ");
        if (m.checkOdd(a)){
            System.out.print(a + ", ");
        }
        if (m.checkOdd(b)){
            System.out.print(b + ", ");
        }
        if (m.checkOdd(c)){
            System.out.print(c + ", ");
        }
        if (m.checkOdd(x1)) {
            System.out.print(x1 + ", ");
        }
        if (m.checkOdd(x2)) {
            System.out.print(x2 + " ");
        }
        System.out.println();
        System.out.print("Number is even: ");
        if (m.checkEven(a)) {
            System.out.print(a + ", ");
        }
        if (m.checkEven(b)) {
            System.out.print(b + ", ");
        }
        if (m.checkEven(c)) {
            System.out.print(c + ", ");
        }
        if (m.checkEven(x1)) {
            System.out.print(x1 + ", ");
        }
        if (m.checkEven(x2)) {
            System.out.print(x2 + " ");
        }
        System.out.println();
        System.out.print("Number is Perfect Square: ");
        if (m.checkPerfectNumber(a)) {
            System.out.print(a + ", ");
        }
        if (m.checkPerfectNumber(b)) {
            System.out.print(b + ", ");
        }
        if (m.checkPerfectNumber(c)) {
            System.out.print(c + ", ");
        }
        if (m.checkPerfectNumber(x1)) {
            System.out.print(x1 + ", ");
        }
        if (m.checkPerfectNumber(x2)) {
            System.out.print(x2 + " ");
        }
        System.out.println();
    }
    
}


