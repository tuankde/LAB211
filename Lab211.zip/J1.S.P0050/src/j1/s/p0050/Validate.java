  /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0050;

import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class Validate {
    
    static Scanner sc = new Scanner(System.in);
    
    public static int menu(){
        System.out.println("=====Equation Program=====");
        System.out.println("1. Calculate Superlative Equation ");
        System.out.println("2. Calculate Quadratic Quation");
        System.out.println("3. Exit");
        System.out.println("Enter your choice:  (1 --> 3)");
        int choice = checkInput(1, 3);
        return choice;
    }
    
    //check input
    public static int checkInput(int min, int max){
        while (true) {            
            try {
                int input = Integer.parseInt(sc.nextLine().trim());
                if (input < min || input > max){
                    throw new NumberFormatException();
                }
                return input;
            } catch (NumberFormatException e) {
                System.out.print("Enter again!!!");
            }
        }
    }
    
    //check input double
    public static double checkInputDouble(){
        while (true) {            
            try {
                double input = Double.parseDouble(sc.nextLine());
                return input;
            } catch (NumberFormatException e) {
                System.out.println("Please input number!!!");
            }
        }
    }
    
    public static boolean checkOdd(double n){
        if (n % 2 != 0){
            return true;
        } else {
            return false;
        }
    }
    
    public static boolean checkEven(double n){
        if (n % 2 == 0){
            return true;
        } else {
            return false;
        }
    }
    
    // check number is perfect number
    
    public static boolean checkPerfectNumber(double n){
        double square = Math.sqrt(n);
        return square == Math.floor(n);
    }
    
}
