/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;

/**
 *
 * @author ADMIN lop chua cac phuong thuc chuyen doi giua cac he co so
 */
public class Convert {

    //phuong thuc chuyen doi tu he co so khac sang he co so 10
    public int OtherToDec(String Other, int base) {
        int result = 0;
        String HEX = "0123456789ABCDEF";
        Other = Other.toUpperCase();//chuyen doi Other thanh chu hoa
        //de khong phan biet hoa/thuong
        for (int i = 0; i < Other.length(); i++) { //lap qua tung ky tu trong Other
            result += HEX.indexOf(Other.charAt(i)) * Math.pow(base, Other.length() - 1 - i); //Get other numbers,multiply number pow
            //result += gia tri cua ky tu * base ^ (so luong ky tu -1-i)
//so mu giam dan theo i
        }
        return result;
    }

    //Phuong thuc chuyen doi tu he co so 10 sang he co so khac
    public String DecToOther(int Dec, int base) {
        String result = " "; //khoi tao bien result voi gia tri rong.
        String HEX = "0123456789ABCDEF";
        while (Dec > 0) {
            //lap cho den khi Dec =0
            result = HEX.charAt(Dec % base) + result;
            //result = ky tu tuong ung voi Dec % base +result
            Dec /= base;
        }
        return result;
    }
}
