/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Validation;

import java.util.Scanner;

/**
 *
 * @author ADMIN lop chua cac phuong thuc de kiem tra va nhap lieu tu nguoi dung
 */
public class Validate {

    Scanner sc = new Scanner(System.in);

    //phuong thuc yeu cau nguoi dung nhap co so
    public int getBase(String msg, String err) {
        while (true) {
            try {
                System.out.println(msg);
                int base = Integer.parseInt(sc.nextLine().trim());
                if (base == 2 || base == 10 || base == 16) {
                    return base;
                }
            } catch (NumberFormatException e) {
                System.out.println(err);
                System.out.println("Please enter number again.");
            }

        }

    }

    //phuong thuc yeu cau nguoi dung nhap gia tri
    public String getValue(String msg, String err, int base) {
        while (true) {

            try {
                System.out.println(msg);
                String value = sc.nextLine().trim();
                switch (base) {
                    case 2:
                        if (value.matches("[0-1]+")) {
                            return value;
                        }
                        break;
                    case 10:
                        if (value.matches("[0-9]+")) {
                            return value;
                        }
                        break;
                    case 16:
                        if (value.matches("[0-9a-fA-F]+")) {
                            return value;
                        }
                        break;

                }
            } catch (Exception e) {
                System.out.println(err);
                System.out.println("Please enter number again.");
            }

        }
    }

}
