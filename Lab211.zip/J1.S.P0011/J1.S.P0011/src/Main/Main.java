/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Manager.Convert;
import Validation.Validate;

/**
 *
 * @author ADMIN lop chua phuong thuc main de chay chuong trinh
 */
public class Main {

    public static void main(String[] args) {
        Validate validate = new Validate();
        Convert convert = new Convert();
        while (true) {
            int inBase = validate.getBase(Resource.IN_BASE, Resource.BASE_INVALID);
            String value = validate.getValue(Resource.ENTER_VALUE, Resource.BASE_INVALID, inBase);
            int outBase = validate.getBase(Resource.OUT_BASE, Resource.BASE_INVALID);

            System.out.println(Resource.CHANGE_BASE);
            if (inBase == 10) {
                //Goi phuong thuc DectoOther de chuyen doi gia tri tu he co so 10 sang he co so dau ra
                System.out.println(convert.DecToOther(Integer.parseInt(value), outBase));
            } else {
                //goi phuong thuc OtherToDec de chuyen doi gia tri tu he co so dau vao sang he co so 10             
                int decTemp = convert.OtherToDec(value, inBase);
                //sau do goi phuong thuc DecToOther de chuyen doi gia tri tu he co so 10 sang he co so dau ra            
                System.out.println(convert.DecToOther(decTemp, outBase));
            }

        }

    }
}
