
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class StudentManager {

    public static void main(String[] args) {

        //tao doi tuong luu tru danh sach
        List<Student> list = new ArrayList<>();

        System.out.println("====== Management Student Program ======");

        //khoi tao doi tuong options
        Options option = new Options();
        Scanner scanner = new Scanner(System.in);
        
        //them hoc sinh 
        while (true) {
            System.out.print("Name: ");
            
            //nhap ten 
            String name = scanner.nextLine();
            System.out.print("Classes: ");
            
            //nhap lop
            String classes = scanner.nextLine();

            //nhap diem toan
            double math = option.checkInputMark("Math");

            //nhap diem hoa
            double chemistry = option.checkInputMark("Chemistry");

            //nhap diem ly
            double physical = option.checkInputMark("Physical");
            
            //them hoc sinh vao danh sach
            option.addStudent(list, name, classes, math, physical, chemistry);
           
            //hoi nguoi dung co muon nhap them thong tin hoc sinh khac hay khong
            //chon N de thoat
            if (option.inputYN().equalsIgnoreCase("N")) {
                break;
            }
        }
        
        //hien thi
        option.display(list);
        
        //luu tru phan tram diem cua hoc sinh
        HashMap<String, Double> mapStudent = option.getPercentTypeStudent(list);
        
        //duyet qua va in ra phan tram diem cua hoc sinh
        mapStudent.forEach((key, value) -> System.out.println(key + ": " + value + "%"));
    }
}
