

/**
 *
 * @author trinh
 */
public class Student {

    /**
     * phuong thuc cua ten ten lop diem toan ly hoa
     */
    private String name;
    private String className;
    private double mathmark;
    private double physicalmark;
    private double chemistrymark;

    public Student() {
    }

    public Student(String name, String className, double math, double physical, double chemistry) {
        this.name = name;
        this.className = className;
        this.mathmark = math;
        this.physicalmark = physical;
        this.chemistrymark = chemistry;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public double getMath() {
        return mathmark;
    }

    public void setMath(double math) {
        this.mathmark = math;
    }

    public double getPhysical() {
        return physicalmark;
    }

    public void setPhysical(double physical) {
        this.physicalmark = physical;
    }

    public double getChemistry() {
        return chemistrymark;
    }

    public void setChemistry(double chemistry) {
        this.chemistrymark = chemistry;
    }

    public String getType(double avg) {
        if (avg > 7.5) {
            return "A";
        } else if (avg >= 6) {
            return "B";
        } else if (avg >= 4) {
            return "C";
        } else {
            return "D";
        }
    }

    //tinh diem trung binh
    public double getAVG() {
        double avg = (mathmark + physicalmark + chemistrymark) / 3;
        return avg;
    }

    //hien thi
    public void dislay() {
        System.out.println("Name: " + name);
        System.out.println("Classes: " + className);
        double avg = (mathmark + physicalmark + chemistrymark) / 3;
        System.out.printf("AVG: %.2f\n", avg);
        System.out.println("Type: " + getType(avg));
    }
}
