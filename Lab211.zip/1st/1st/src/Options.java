
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author
 */
public class Options {

    static final Scanner scanner = new Scanner(System.in);

    /**
     * kiem tra va nhap diem cho hoc sinh
     * 
     * @param nameSubject
     * @return 
     */
    public double checkInputMark(String nameSubject) {
        double input;
        while (true) {
            try {
                System.out.print(nameSubject + ": ");
                input = Double.parseDouble(scanner.nextLine());

                //neu diem be hon 0
                if (input < 0) {
                    System.out.print(nameSubject);
                    System.out.println("is greater than equal zero.");
                    
                //neu diem lon hon 10
                } else if (input > 10) {
                    System.out.print(nameSubject);
                    System.out.println("is less than equal ten");
                } else {
                    return input;
                }
            } catch (NumberFormatException e) {
                System.out.print(nameSubject);
            }
        }

    }

    /**
     * nhap yes / no từ người dùng
     * @return 
     */
    public static String inputYN() {
        
        while (true) {
            System.out.print("Do you want to enter more student information?(Y/N):");
            String choice = scanner.nextLine();
            if (choice.equalsIgnoreCase("N") || choice.equalsIgnoreCase("Y")) {
                return choice;
            } else {
                System.out.println("Please input Y or N");
            }
        }
    }

    /**
     * them hoc sinh vao danh sach
     * @param list
     * @param name
     * @param className
     * @param math
     * @param chemistry
     * @param physical 
     */
    public void addStudent(List<Student> list, String name, String className, double math,
            double chemistry, double physical) {
        list.add(new Student(name, className, math, physical, chemistry));
    }

    /**
     * hien thi thong tin hoc sinh
     * 
     * @param list 
     */
    public void display(List<Student> list) {
        int index = 0;
        for (Student o : list) {
            System.out.println("------ Student" + index + " Info ------");
            o.dislay();
            index++;
        }
    }

    /**
     * tinh phan tram tung loai hoc sinh
     * 
     * @param list
     * @return 
     */
    public HashMap<String, Double> getPercentTypeStudent(List<Student> list) {
        //A: 30%
        //B: 20%
        //C: 40%
        //D: 10%
        HashMap<String, Double> hashMap = new HashMap<>();
        int countA = 0;
        int countB = 0;
        int countC = 0;
        int countD = 0;
        for (Student student : list) {
            if (student.getAVG() > 7.5) {
                countA++;
            } else if (student.getAVG() >= 6) {
                countB++;
            } else if (student.getAVG() >= 4) {
                countC++;
            } else {
                countD++;
            }
        }
        int totalStudent = list.size();
        hashMap.put("A", 100.0 * countA / totalStudent);
        hashMap.put("B", 100.0 * countB / totalStudent);
        hashMap.put("C", 100.0 * countC / totalStudent);
        hashMap.put("D", 100.0 * countD / totalStudent);
        return hashMap;
        
    }
}
