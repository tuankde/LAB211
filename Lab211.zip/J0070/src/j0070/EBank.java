package j0070;

import java.util.*;
import java.util.regex.Pattern;

public class EBank {

    private ResourceBundle messages;
    private Scanner sc = new Scanner(System.in);
    private final String character = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm0123456789";

    public void setLocale(Locale locale) {
        messages = ResourceBundle.getBundle("Language/" + locale, locale);
    }

    public String checkAccountNumber(String accountNumber) {
        if (!accountNumber.matches("\\d{10}")) {
            return messages.getString("errCheckInputAccount");
        }
        return null; // Valid account number
    }

    public String checkPassword(String password) {
        if ((password.length() < 8) || (password.length() > 31)|| 
            !password.matches(".*\\d.*[a-zA-Z].*") && !password.matches(".*[a-zA-Z].*\\d.*")) {
            return messages.getString("errCheckInputPassword");
        }
        return null; // Valid password
    }

    
    public String generateCaptcha() {
        Random random = new Random();
        String captcha = "";
        int index;
        for (int i = 0; i < 6; i++) {
            index = (random.nextInt(character.length() - 1));
            captcha += character.charAt(index);
        }
        return captcha;
    }

    public String checkCaptcha(String captchaInput, String captchaGenerated) {
        if (!captchaGenerated.equals(captchaInput)) {
            return messages.getString("errCaptchaIncorrect");
        }
        return null; // Valid captcha
    }

    public String inputAccount() {
        //input account.
        String account;
        String accountMessage;
        while (true) {
            System.out.println(messages.getString("enterAccountNumber"));
            account = sc.nextLine();
            accountMessage = checkAccountNumber(account);
            if (accountMessage != null) {
                System.out.println(accountMessage);
            } else {
                return account;
            }
        }
    }

    public String inputPassword() {
        //input account.
        String password;
        String passwordMessage;
        while (true) {
            System.out.println(messages.getString("enterPassword"));
            password = sc.nextLine();
            passwordMessage = checkPassword(password);
            if (passwordMessage != null) {
                System.out.println(passwordMessage);
            } else {
                return password;
            }
        }
    }

    public String inputCaptcha() {
        String generateCaptcha = generateCaptcha();
        System.out.println("Capcha : " + generateCaptcha);
        String capcha;
        String capchaMessage;
        while (true) {
            System.out.println(messages.getString("enterCaptcha"));
            capcha = sc.nextLine();
            capchaMessage = checkCaptcha(capcha, generateCaptcha);
            if (capchaMessage != null) {
                System.out.println(capchaMessage);
            } else {
                return capcha;
            }
        }
    }

    public void login() {
        String account = inputAccount();
        String password = inputPassword();
        String captcha = inputCaptcha();
        System.out.println(messages.getString("loginSuccess"));
    }

    public int checkInputIntLimit(int min, int max) {
        while (true) {
            try {
                int result = Integer.parseInt(sc.nextLine());
                if (result < min || result > max) {
                    throw new NumberFormatException();
                }
                return result;
            } catch (NumberFormatException ex) {
                System.out.println(messages.getString("errorCheckInputIntLimit"));
                System.out.println();
            }
        }
    }
}
