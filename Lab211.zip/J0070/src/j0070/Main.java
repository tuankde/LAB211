package j0070;

import java.util.Locale;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        EBank ebank = new EBank();
        System.out.println("-----Login Program-----");
        System.out.println("1. Vietnamese");
        System.out.println("2. English");
        System.out.println("3. Exit");
        System.out.print("Please choice one option: ");
        Locale vietnamese = new Locale("vi");
        Locale english = new Locale("En");
        int choice = ebank.checkInputIntLimit(1, 2);
        switch (choice) {
            case 1:
                ebank.setLocale(vietnamese);
                ebank.login();
                break;
            case 2:
                ebank.setLocale(english);
                ebank.login();
                break;
            case 3:
                return;
        }
    }
    
}
