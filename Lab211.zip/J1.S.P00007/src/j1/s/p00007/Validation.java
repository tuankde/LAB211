/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p00007;

import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class Validation {
    final static Scanner scanner = new Scanner(System.in);
    
    //kiem tra va lay so nguyen trong 1 khoang cu the
    public static int checkPoint(int maxEgde){
        while (true) {            
            try {
                int input = Integer.parseInt(scanner.nextLine());
                
                //kiem tra xem co nam trong khoang tu 1 den egde khong
                if (input <= 0 || input >= maxEgde + 1){
                    throw new NumberFormatException("Enter an integer between 1 and " + maxEgde);
                }
                return input;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a positive number!");
            }
        }
    }
}
