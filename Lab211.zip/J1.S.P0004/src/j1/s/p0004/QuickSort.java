/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0004;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class QuickSort {

     //random
    public static int[] randomArray(int size){
        Random rd = new Random();
        int[] arr = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = rd.nextInt(10);
        }
        return arr;
    } 
    
    /**
     * phân chia mảng thành các phần con dựa trên giá trị của phần tử pivot.
     * @param arr
     * @param left
     * @param right
     * @return 
     */
    public static int partition(int arr[], int left, int right) {
        
        //khoi tao 2 bien cho phan dau va cuoi cua mang
        int low = left, high = right;
        
        //dung de trao doi gia tri phan tu
        int temp;
        
        //chon phan tu pivot o giua mang
        int pivot = arr[(low + high) / 2];

        //  Vòng lặp chạy cho đến khi low và high gặp nhau.
        while (low <= right) {
            
            //tìm phần tử bên trái lớn hơn hoặc bằng pivot.
            while (arr[low] < pivot) {
                low++;
            }
            
            // tìm phần tử bên phải nhỏ hơn hoặc bằng pivot
            while (arr[high] > pivot) {
                high--;
            }
            
            //hoan doi
            if (low <= high) {
                temp = arr[low];
                arr[low] = arr[high];
                arr[high] = temp;
                low++;
                high--;
            }
        };
        //tra ve vi tri diem chot pivot
        return low;
    }

    /**
     * sap xep
     * @param arr
     * @param left
     * @param right 
     */
    public static void quickSort(int arr[], int left, int right) {
        
        //chia mang thanh 2 phan va lay diem chot
        int index = partition(arr, left, right);
        
        //sap xep phan ben trai
        if (left < index - 1) {
            quickSort(arr, left, index - 1);
        }
        
        //sap xep phan bên phai
        if (index < right) {
            quickSort(arr, index, right);
        }
    }
    //Display
    public static void display(int[] arr){
        System.out.print("[");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]);
            if (i < arr.length - 1){
                System.out.print(", "); 
            }
        }
        System.out.println("]");
    }
    
    public static void main(String[] args) {
        //Enter size of array
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of array:");
        int n = sc.nextInt(); 
        int[] arr = randomArray(n);
        
        //Display array before
        System.out.print("Unsorted array: ");
        display(arr);
        
        //Sort array
        quickSort(arr, 0, n -1);
        
        //Display array after
        System.out.print("Sorted array: ");
        display(arr);
    }
    
}
