/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.p0052;

/**
 *
 * @author Acer
 */
public class EastAsiaCountry extends Country{
    private String terrain;

    public EastAsiaCountry() {
    }

    public EastAsiaCountry(String terrain) {
        this.terrain = terrain;
    }

    public EastAsiaCountry(String code, String name, float area, String terrain) {
        super(code, name, area);
        this.terrain = terrain;
    }

    public String getTerrain() {
        return terrain;
    }

    public void setTerrain(String terrain) {
        this.terrain = terrain;
    }
    
    @Override
    public void display(){
        super.display();
        System.out.format("%-10s\n", terrain);
    }
    
}
