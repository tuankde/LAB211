/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.p0052;



/**
 *
 * @author Acer
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void diaplayMenu() {
        System.out.println("\t\t\tMENU");
        System.out.println("=====================================================================");
        System.out.println("1. Input the infomation of 11 countries in East Asia");
        System.out.println("2. Display the infomation of country you're just input");
        System.out.println("3. Search the infomation of country by user-entered name");
        System.out.println("4. Display the infomation of countries sorted mane in ascending order");
        System.out.println("5. Exit");
        System.out.println("=====================================================================");
    }
    
    
    public static void main(String[] args) {
        
    }
    
}
