/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.p0052;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author Acer
 */
public class Manager {
    ArrayList<EastAsiaCountry> countryList;
    
    public Manager(){
        countryList = new ArrayList<>();
        countryList.add(new EastAsiaCountry("VN", "Viet Nam", 1000, "A"));
        countryList.add(new EastAsiaCountry("IDN", "Indonesia", 1000, "A"));
        countryList.add(new EastAsiaCountry("TL", "Thai Lan", 1000, "A"));
        countryList.add(new EastAsiaCountry("SGP", "Singapore", 1000, "A"));
    }
    
    public void addCountry(EastAsiaCountry country){
        countryList.add(country);
    }
    
    //check duplicateCode: neu dinh thi tra ve true, con lai false
    // loop for each element in countryList
    
    boolean isDuplicateCode(String code){
        for (EastAsiaCountry est : countryList){
            //check element
            if (est.getCode().equalsIgnoreCase(code)){
                return true;
            }
        }
        return false;
    }
    
    boolean isDuplicateName(String name){
        for (EastAsiaCountry est : countryList){
            //check element
            if (est.getName().equalsIgnoreCase(name)){
                return true;
            }
        }
        return false;
    }
    
    ArrayList<EastAsiaCountry> searchByName(String name){
        ArrayList<EastAsiaCountry> searchList = new ArrayList<>();
        //loop each element
        for (EastAsiaCountry est : countryList){
            if (est.getName().toUpperCase().contains(name.toUpperCase())) {
                searchList.add(est);
            }
        }
        return searchList;
    }
    
    void sortCountry(ArrayList<EastAsiaCountry> sortList){
        Collections.sort(sortList, new Comparator<EastAsiaCountry>() {
            @Override
            public int compare(EastAsiaCountry o1, EastAsiaCountry o2) {
                //sort
                return o1.getName().compareToIgnoreCase(o2.getName());
            }
        }) ;
    }
    
    
    
    
    
    
    
    
}
