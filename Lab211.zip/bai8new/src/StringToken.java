import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
/**
 * 
 * @author Acer
 */
public class StringToken {

    public static void main(String[] args) {
        // Bước 1: Nhập chuỗi
        String string = InputString("Enter the content: ");

        // Bước 2: Đếm số từ trong chuỗi
        Map<String, Integer> countWords = countWords(string);

        // Bước 3: Hiển thị số từ và số chữ cái
        Map<Character, Integer> countLetters = countLetters(string);

        // Bước 4: Hiển thị số từ
        DisplayWordCount(countWords);

        // Bước 5: Hiển thị số chữ cái
        DisplayLetterCount(countLetters);
    }

    private static String InputString(String str) {
        // Hàm để nhập và kiểm tra tính hợp lệ của chuỗi đầu vào
        // Sử dụng một đối tượng Scanner để đọc dữ liệu từ bàn phím
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println(str);
            String string = sc.nextLine();
            if (string.isEmpty()) {
                System.out.print("Vui lòng nhập chuỗi của bạn!");
                continue;
            }
            if (!string.matches("^[A-Za-z0-9\\s]+$")) {
                System.out.println("Vui lòng nhập chuỗi chỉ chứa chữ cái, số và khoảng trắng!");
                continue;
            }
            return string;
        }
    }

    /**
     * 
     * @param string
     * @return 
     */
    private static Map<String, Integer> countWords(String string) {
        // Hàm này đếm số từ trong chuỗi và lưu kết quả vào một đối tượng Map
        Map<String, Integer> countWords = new HashMap<>();
        StringTokenizer token = new StringTokenizer(string);
        while (token.hasMoreTokens()) {
            String words = token.nextToken();
            if (!countWords.containsKey(words)) {
                countWords.put(words, 1);
            } else {
                countWords.put(words, ((int) countWords.get(words)) + 1);
            }
        }
        return countWords;
    }

    /**
     * 
     * @param string
     * @return đếm số từ
     */
    private static Map<Character, Integer> countLetters(String string) {
        // Hàm này đếm số lần xuất hiện của các ký tự trong chuỗi (loại trừ khoảng trắng)
        Map<Character, Integer> countLetters = new HashMap<>();
        for (char ch : string.toCharArray()) {
            if (Character.isSpaceChar(ch))
                continue;
            if (!countLetters.containsKey(ch)) {
                countLetters.put(ch, 1);
            } else {
                countLetters.put(ch, ((int) countLetters.get(ch)) + 1);
            }
        }
        return countLetters;
    }

    /**
     * 
     * @param countWords 
     */
    private static void DisplayWordCount(Map<String, Integer> countWords) {
        // Hàm này hiển thị số lần xuất hiện của các từ trong chuỗi
        System.out.println(countWords);
    }

    /**
     * 
     * @param countLetters 
     */
    private static void DisplayLetterCount(Map<Character, Integer> countLetters) {
        // Hàm này hiển thị số lần xuất hiện của các ký tự trong chuỗi (loại trừ khoảng trắng)
        System.out.println(countLetters);
    }
}
