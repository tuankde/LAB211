

/**
 *
 * @author Acer
 */
public class Resource {
    
}
