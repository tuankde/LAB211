/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package selectionsort;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class SelectionSort {

    //random
    public static int[] randomArray(int size){
        Random rd = new Random();
        int[] arr = new int[size];
        for (int i = 0; i < size; i++) {
            arr[i] = rd.nextInt(10);
        }
        return arr;
    } 
    
    //Sort
    static void selectSortArray(int[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            int min = i;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[min] > arr[j]){
                    min = j;
                }
            }
            int temp = arr[min];
            arr[min] = arr[i];
            arr[i] = temp;
        }
    }
    
    //Display
    public static void display(int[] arr){
        System.out.print("[");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]);
            if (i < arr.length - 1){
                System.out.print(", "); 
            }
        }
        System.out.println("]");
    }
    
    public static void main(String[] args) {
        //Enter size of array
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of array:");
        int n = sc.nextInt(); 
        int[] arr = randomArray(n);
        
        //Display array before
        System.out.print("Unsorted array: ");
        display(arr);
        
        //Sort array
        selectSortArray(arr);
        
        //Display array after
        System.out.print("Sorted array: ");
        display(arr);
        
    }
    
}
