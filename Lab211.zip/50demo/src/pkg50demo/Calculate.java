/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg50demo;

import java.util.ArrayList;
import java.util.List;



/**
 * @version 
 * @author Acer
 */
public class Calculate {
    static Validation number = new Validation();
     
    // Method to calculate the solutions of a superlative equation
    /**
     * 
     * @param numberA
     * @param numberB
     * @return danh sach nghiem hoac null neu k co nghiem
     */
    public static List<Double> calculateEquation(double numberA,double numberB) {
        // tao 
        List<Double> solutions = new ArrayList<>();
        if (numberA == 0) {
            return null; // No solution for a superlative equation with a = 0.
        } else {
            double solution = -numberB/ numberA;
            solutions.add(solution);
        }
        return solutions;
    }
    
    //// Phương thức để hiển thị số lẻ, số chẵn và số bình phương từ các hệ số cho trước
public static void displayOddEvenSquareNumbers(Validation... number) {
    // Hiển thị số lẻ
    System.out.print(Resource.oddNumber);
    for (Validation oddNumber : number) {
        if (Validation.checkOdd(oddNumber)) {
            System.out.print(oddNumber + Resource.space);
        }
    }

    // Hiển thị số chẵn
    System.out.print(Resource.evenNumber);
    for (Validation evenNumber : number) {
        if (!Validation.checkEven(evenNumber)) {
            System.out.print(evenNumber + Resource.space);
        }
    }

    // Hiển thị số bình phương
    System.out.print(Resource.squareNumber);
    for (Validation perfectNumber : number) {
        if (Validation.checkPerfectNumber(perfectNumber)) {
            System.out.print(perfectNumber + Resource.space);
        }
    }
    System.out.println();
}
    
    //1
    public static void superlativeEquation(){
        System.out.print(Resource.enter);
        double numberA = Validation.checkInputDouble();
        System.out.print(Resource.enter1);
        double numberB = Validation.checkInputDouble();
        
        //calculate
        List<Double> solutions = calculateEquation(numberA, numberB);
        if (solutions == null) {
            System.out.println(Resource.solution1);
            //check empty
        } else if (solutions.isEmpty()){
            System.out.println(Resource.empty);
        } else {
            System.out.println(Resource.solution + solutions);
            displayOddEvenSquareNumbers(number);
        }
        
        
    }
}
