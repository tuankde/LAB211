/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg50demo;

import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println(Resource.title);
            System.out.println(Resource.title1);
            System.out.println(Resource.title2);
            System.out.println(Resource.title3);
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    
                    break;
                case 2:
                    
                    break;
                case 3:
                    System.out.println(Resource.exit);
                    return;
                default:
                    System.out.println(Resource.error);
            }
        }
    }
    
}
