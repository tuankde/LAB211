
package pkg50demo;

import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class Validation {
    static Scanner sc = new Scanner(System.in);
    
    //check input double
    public static double checkInputDouble(){
        while (true) {            
            try {
                double input = Double.parseDouble(sc.nextLine());
                return input;
            } catch (NumberFormatException e) {
                System.out.println("Please input number!!!");
            }
        }
    }
    
    public static boolean checkOdd(double n){
        if (n % 2 != 0){
            return true;
        } else {
            return false;
        }
    }
    
    public static boolean checkEven(double n){
        if (n % 2 == 0){
            return true;
        } else {
            return false;
        }
    }
    
    // check number is perfect number
    
    public static boolean checkPerfectNumber(double n){
        double square = Math.sqrt(n);
        return square == Math.floor(n);
    }

    static boolean checkOdd(Validation oddNumber) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    static boolean checkEven(Validation evenNumber) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    static boolean checkPerfectNumber(Validation perfectNumber) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
