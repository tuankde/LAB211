/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg50demo;

/**
 *
 * @author Acer
 */

public class Resource {
    final static String title = "=====Equation Program=====";
    final static String title1 = "1. Calculate Superlative Equation";
    final static String title2 = "2. Calculate Quadratic Equation";
    final static String title3 = "3. Exit";
    final static String error = "Invalid option. Please try again.";
    final static String exit = "Exiting the program. Goodbye!";
    final static String enter = "Enter A: ";
    final static String enter1 = "Enter B: ";
    final static String enter2 = "Enter C: ";
    final static String solution = "Solution : x = %.3f\n";
    final static String oddNumber = "Number is odd: ";
    final static String solution1 = "No solution exists.";
    final static String empty = "Infinite solutions.";
    final static String evenNumber = "\nNumber is even: ";
    final static String squareNumber = "\nNumber is Perfect Square: ";
    final static String space = " ";
    final static String
}
