/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0007;

import java.util.Scanner;

// Lớp tiện ích dùng để xác minh đầu vào của người dùng
public class J1SP0007 {

    // Phương thức này kiểm tra xem có cạnh nối giữa hai điểm trong đồ thị không
    /**
     * 
     * @param start
     * @param end
     * @param AdjMatrix
     * @return 
     */
    public static String checkEdge(int start, int end, int[][] AdjMatrix) {

        // Kiểm tra giá trị trong ma trận kề xem có cạnh nối giữa hai điểm hay không
        if (AdjMatrix[start - 1][end - 1] == 1) {
            return "This is an edge";
        }
        return "This is not an edge";
    }

    // Phương thức này thêm một cạnh nối giữa hai điểm trong đồ thị
    /**
     * 
     * @param start
     * @param end
     * @param AdjMatrix 
     */
    public static void addPoint(int start, int end, int[][] AdjMatrix) {

        // Thêm cạnh nối bằng cách đặt giá trị trong ma trận kề
        AdjMatrix[start - 1][end - 1] = 1;
        AdjMatrix[end - 1][start - 1] = 1;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("Enter the start point: ");
        int start = Validate.checkPoint(5);

// Gọi phương thức xác minh và lấy điểm bắt đầu
        System.out.println("Enter the end point: ");
        int end = Validate.checkPoint(5);

// Gọi phương thức xác minh và lấy điểm kết thúc
        int[][] AdjMatrix = new int[5][5];
        // Khởi tạo ma trận kề để lưu trữ cấu trúc đồ thị và kiểm tra cạnh nối giữa hai đỉnh
        // Khởi tạo ma trận kề với các giá trị ban đầu là 0
        for (int i = 0; i <= 4; ++i) {
            for (int j = 0; j <= 4; ++j) {
                AdjMatrix[i][j] = 0;
            }
        }

        // Thêm cạnh vào đồ thị
        addPoint(3, 5, AdjMatrix);
        addPoint(2, 5, AdjMatrix);
        addPoint(1, 4, AdjMatrix);
        addPoint(2, 4, AdjMatrix);
        addPoint(5, 4, AdjMatrix);

        // Hiển thị ma trận kề
        for (int i = 0; i <= 4; ++i) {
            for (int j = 0; j <= 4; ++j) {
                System.out.print(AdjMatrix[i][j] + " ");
            }
            System.out.println();
        }

        // Kiểm tra và hiển thị xem có cạnh nối giữa hai điểm đã cho không
        System.out.println(checkEdge(start, end, AdjMatrix));
    }
}
