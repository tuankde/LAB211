/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package j1.s.p0007;

import java.util.Scanner;

/**
 *
 * @author Vinh
 */

// Lớp tiện ích dùng để xác minh đầu vào của người dùng
public class Validate {
    private final static Scanner sc = new Scanner(System.in);

    // Phương thức này kiểm tra và lấy một số nguyên nằm trong một khoảng cụ thể
    public static int checkPoint(int maxEdge) {
        while (true) {
            try {
                
                // Đọc dữ liệu nhập từ bàn phím
                int rs = Integer.parseInt(sc.nextLine());
                
                // Kiểm tra xem số nguyên này có nằm trong khoảng từ 1 đến maxEdge không
                if (rs <= 0 || rs >= maxEdge + 1) {
                    throw new NumberFormatException("Please enter an integer between 1 and " + maxEdge);
                }
                return rs;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a positive integer");
            }
        }
    }
}
