/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tt;

/**
 *
 * @author Acer
 */
public class Tt {

    
    public static void main(String[] args) {
//        int x = 10;
//        System.out.println("10 * 10 = " + x * x);
        float f;
        System.out.printf("%.2f" + 3.14566);
    }
    
}
